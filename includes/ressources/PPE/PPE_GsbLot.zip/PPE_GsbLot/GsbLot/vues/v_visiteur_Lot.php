<?php 
    $DrawTable = false;
    if(isset($_REQUEST["Sumbmited"])  && isset($_REQUEST["Medicament"]) && isset($_REQUEST["Medecin"]) && isset($_REQUEST["Date"])){
        if($_REQUEST["Medicament"] >= 0 && $_REQUEST["Medecin"] >= 0  && $_REQUEST["Date"] != "" ){
            $DrawTable = true;

            $date = $_REQUEST["Date"];
            $numMedecin = $_REQUEST["Medecin"]; 
            $leMedoc = $_REQUEST["Medicament"];   
            $lesMedocs = getLesMedicamentSortie( $leMedoc);
        
        }

    }

?>

<div id ="CenterHor">
    <form action="index.php?uc=visiteur&action=VisiteurLot&Sumbmited=true" method="Post">

        <div id=""></div>
        <p>Date visite :</p>
        <input type="date" class="inputText" name="Date">
        <p>Medecin :</p>
        <?php 
        echo '<select class="inputText" name="Medecin" id="">';
        echo '<option class="SpecialTxt"  value="-1"> </option>';
        foreach ($LesMedecins as $LeMedecin) {
            echo ' <option class="SpecialTxt" value="'.$LeMedecin["numMedecin"].'">'.$LeMedecin["nomMedecin"].' '.$LeMedecin["prenomMedecin"].'</option>';
            echo $LeMedecin["nomMedecin"];
        } 
        echo'</select>';

        ?>
        <p>Médicament :</p>

        <?php 
            echo '<select class="inputText" name="Medicament" >';
            echo '<option class="SpecialTxt" value="-1"> </option>';
            foreach ($LesMedicaments as $LeMedicament) {
                echo '<option     value="'.$LeMedicament["numMedicament"].'">'.$LeMedicament["nomMedicament"].'</option>';
                echo $LeMedecin["nomMedecin"];
            } 
            echo'</select>';

        ?>
        <br>
        <br>

        <input class ="ButtonS" type="submit" value="Visualiser">
        <input class="button deco" type="submit" value="Retour" formaction="index.php?uc=visiteur">
    </form>
    </div>

<?php 
    if($DrawTable){
   
        
        echo '<div id ="CenterHor">
             <form class="formVisiteur"  method="Post" action="index.php?uc=visiteur&action=VisiteurLot&&Date='.$date.'&&Medecin='.$numMedecin.'">
            

                    
                    <table name="table">   
                    <tr>
                        <th >Numéro de lot</th>
                        <th>Numéro échantillon</th>
                        <th>Déposer</th>  
                    </tr>
                        ';
                        foreach ($lesMedocs as $LeMedoc) {
                           echo' <tr>
                            <td>'.$LeMedoc["lot"].'</td>
                            <td>'.$LeMedoc["numEchantillon"].'</td>
                            <td><input class="cb" name ="cb'.$LeMedoc["lot"].'*'.$LeMedoc["numEchantillon"].'" type="checkbox"></td>
                            </tr>
                            ';
                        }
                        echo '
                        </table>
                
           

                <div id ="CenterHor">
                    <input  class="ButtonS" id="BtEnvoyerVisiteur" type="Submit">
                </div>

            </form>       
        </div>';
        



    }

    
?>