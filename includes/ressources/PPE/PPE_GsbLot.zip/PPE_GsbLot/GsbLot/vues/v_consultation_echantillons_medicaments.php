

<div class ="home">
	<form method ="post" action="index.php?uc=visiteur&action=EnchMed&submited">
		    <?php  
		     	echo '<select class="SpecialTxt" name="Medicament" >';
            	echo '<option  class="SpecialTxt"  value="-1"> </option>';

			    foreach ($LesMedicaments as $LeMedicament) {
	                echo '<option  class="SpecialTxt" value="'.$LeMedicament["numMedicament"].'">'.$LeMedicament["nomMedicament"].'</option>';
	            } 

            	echo'</select>';
            ?>
		<input class="ButtonS" type="Submit" name="" value="Valider">
	</form>

	<?php 
		if (isset($_REQUEST["submited"])) {
			$echantillon = getEchantillonMedicament($_REQUEST["Medicament"]);
			if(count( $echantillon)> 0 ){

				echo ' <table name="table" class="table table-striped">   
	                    <tr>
	                        <th>Visiteur</th>
	                        <th>Medicament</th>
	                    </tr>
	                        ';
	                        foreach ($echantillon as $ech) {
	                           echo' <tr>
	                            <td>'.$ech["nomMedecin"].' '.$ech["prenomMedecin"].'</td>
	                            <td>'.$ech["dateVisite"].'</td>
	                            </tr>
	                            ';

	                        }
	                        echo '
	            </table>';
            }
            else{
            	echo "<br>";
            	echo "aucun échantillon n'a été trouvé";
            }
		}
 	?>

</div>



