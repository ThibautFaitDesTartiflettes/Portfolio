<?php

    echo '<div class="title">Magasin
            <div class="connected">Vous êtes connecté en tant que : 
            '.$DonneesUtil['prenomUtilisateur'].' '.$DonneesUtil['nomUtilisateur'].'</div>
        </div>';

?>
<div class="content">
    <a href="index.php?uc=magasin&action=renseigner">
        <img src="includes/images/renseigner_medoc.jfif">
        <div class="button">Renseigner Attribution des échantillons</div>
    </a>
    <a href="index.php?uc=magasin&action=consulter">
        <img src="includes/images/Consult_medoc.jfif">
        <div class="button">Consulter les échantillons</div>
    </a>
</div>
<a href="index.php?uc=deconnexion">
    <div class="deco button">Déconnexion</div>
</a>