<div class="title">Consulter les lots</div>
<br/>
<div class="consulterMedoc">
    <h3>Consulter par Médicament</h3>
    <br/>
    <form method="POST" action="index.php?uc=production&action=consulterMedoc">
        <span>Médicament : </span>
        <select name="Medicament">
            <?php
                foreach ($DonneesMedoc as $Medoc) {
                    echo '<option value="'.$Medoc['numMedicament'].'">'.$Medoc['nomMedicament'].'</option>';
                }
            ?>
        </select>
        <br/>
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<br/><br/><br/>
<div class="consulterDate">
    <h3>Consulter par Date</h3>
    <br/>
    <form method="POST" action="index.php?uc=production&action=consulterDate">
        <span>Sélectioner une date : </span>
        <input type="date" name="calendrier">
        <br/>
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<a href="index.php?uc=production&action=afficher"><div class="button deco">Retour</div></a>