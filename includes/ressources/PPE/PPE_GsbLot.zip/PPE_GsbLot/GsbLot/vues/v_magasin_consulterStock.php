<?php  
    if (empty($ConsulterLeStock)) {
        $message = "Aucun Echantillon en stock";
        $redirection = "index.php?uc=magasin&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }  
    else{
        echo '<div class="title"> Consultation du stock </div>';
        echo '<table>
                <tr>
                    <td>Numéro échantillon</td>
                    <td>Numéro lot</td>
                    <td>Nom du médicament</td>
                </tr>';
            foreach ($ConsulterLeStock as $info) {
                echo '<tr>
                        <td>'.$info["numEchantillon"].'</td>
                        <td>'.$info["numLot"].'</td>
                        <td>'.$info["nomMedicament"].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=magasin&action=consulter"><div class="button">Retour</div></a>';
    } 
        
?>