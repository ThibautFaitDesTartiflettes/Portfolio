<?php
    if (empty($ConsulterParVisiteur)) {
        $message = "Aucun Echantillon pour : ".$visiteur."";
        $redirection = "index.php?uc=magasin&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }
    else {
        echo '<div class="title"> Recherche pour le Visiteur : '.$Visiteur.'</div>';
        echo '<table>
                <tr>
                    <td>Medicament</td>
                    <td>Date de sortie</td>
                </tr>';
            foreach ($ConsulterParVisiteur as $info) {
                echo '<tr>
                        <td>'.$info["nomMedicament"].'</td>
                        <td>'.$info["dateSortie"].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=magasin&action=consulter"><div class="button">Retour</div></a>';
    }
?>