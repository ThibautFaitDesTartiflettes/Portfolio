<?php

    echo '<div class="title">Production
            <div class="connected">Vous êtes connecté en tant que : 
            '.$DonneesUtil['prenomUtilisateur'].' '.$DonneesUtil['nomUtilisateur'].'</div>
        </div>';

?>
<div class="content">
    <a href="index.php?uc=production&action=enregistrer">
        <img src="includes/images/enregistrer_medoc.jpg">
        <div class="button">Enregistrer un lot</div>
    </a>
    <a href="index.php?uc=production&action=consulter">
        <img src="includes/images/consulter_medoc.jpg">
        <div class="button">Consulter les lots</div>
    </a>
</div>
<a href="index.php?uc=deconnexion">
    <div class="deco button">Déconnexion</div>
</a>