<?php

echo '<div align="center">'
	. '<h5 style="color: '.$couleur.'">'.$message.'</h5>'
        . '<a href="'.$redirection.'">Retour</a>'
        . '</div>';

?>