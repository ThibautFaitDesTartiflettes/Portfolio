

<div class ="home">
	<form method ="post" action="index.php?uc=visiteur&action=EnchDate&submited">
		<input class="SpecialTxt" type="date" id="start" name="Date">
		<input class="ButtonS" type="Submit" name="" value="Valider">
	</form>

	<?php 
	
		if (isset($_REQUEST["submited"])) {
			$echantillon = getEchantillonDate($_REQUEST["Date"]);
			if(count( $echantillon)> 0 ){

				echo ' <table name="table" class="table table-striped">   
	                    <tr>
	                        <th>Visiteur</th>
	                        <th>Medicament</th>
	                    </tr>
	                        ';
	                        foreach ($echantillon as $ech) {
	                           echo' <tr>
	                            <td>'.$ech["nomUtilisateur"].' '.$ech["prenomUtilisateur"].'</td>
	                            <td>'.$ech["nomMedicament"].'</td>
	                            </tr>
	                            ';

	                        }
	                        echo '
	            </table>';
            }
            else{
            	echo "<br>";
            	echo "aucun échantillon n'a été trouvé";
            }
		}
 	?>

</div>



