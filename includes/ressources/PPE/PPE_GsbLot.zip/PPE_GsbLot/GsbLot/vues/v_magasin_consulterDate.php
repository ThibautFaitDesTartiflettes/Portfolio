<?php
    if (empty($ConsulterDateSortie)) {
        $message = "Aucun Echantillon pour la date : ".$_POST['calendrier']."";
        $redirection = "index.php?uc=magasin&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }
    else {
        echo '<div class="title">Recherche pour la date : </br>'.$_POST['calendrier'].'</div>';
        echo '<table>
                <tr>
                    <td>Visiteur</td>
                    <td>Médicament</td>
                </tr>';
            foreach ($ConsulterDateSortie as $info) {
                echo '<tr>
                        <td>'.$info['nomUtilisateur'].' '.$info['prenomUtilisateur'].'</td>
                        <td>'.$info['nomMedicament'].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=magasin&action=consulter"><div class="button">Retour</div></a>';
    }
?>