<?php
    if (empty($ConsulterParMedoc)) {
        $message = "Aucun Echantillon pour : ".$Medicament."";
        $redirection = "index.php?uc=magasin&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }
    else {
        echo '<div class="title"> Recherche pour le médicament : '.$Medicament.'</div>';
        echo '<table>
                <tr>
                    <td>Visiteur</td>
                    <td>Date de sortie</td>
                </tr>';
            foreach ($ConsulterParMedoc as $info) {
                echo '<tr>
                        <td>'.$info["nomUtilisateur"].' '.$info["prenomUtilisateur"].'</td>
                        <td>'.$info["dateSortie"].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=magasin&action=consulter"><div class="button">Retour</div></a>';
    }
?>