

<div class ="home">
	<form method ="post" action="index.php?uc=visiteur&action=EnchMedecin&submited">
		<?php 
	        echo '<select class="SpecialTxt" name="Medecin" id="">';
        	echo '<option  class="SpecialTxt" value="-1"> </option>';
        	foreach ($LesMedecins as $LeMedecin) {
	            echo ' <option class="SpecialTxt" value="'.$LeMedecin["numMedecin"].'">'.$LeMedecin["nomMedecin"].' '.$LeMedecin["prenomMedecin"].'</option>';
	            echo $LeMedecin["nomMedecin"];
        	} 
       		 echo'</select>';
		 ?>
		<input class="ButtonS" type="Submit" name="" value="Valider">
	</form>

	<?php 

		if (isset($_REQUEST["submited"])) {
			$echantillon = getEchantillonMedecin($_REQUEST["Medecin"]);
			if(count( $echantillon)> 0 ){

				echo ' <table name="table" class="table table-striped">   
	                    <tr>
	                        <th>Visiteur</th>
	                        <th>Medicament</th>
	                    </tr>
	                        ';
	                        foreach ($echantillon as $ech) {
	                           echo' <tr>
	                            <td>'.$ech["dateVisite"].'</td>
	                            <td>'.$ech["nomMedicament"].'</td>
	                            </tr>
	                            ';

	                        }
	                        echo '
	            </table>';
            }
            else{
            	echo "<br>";
            	echo "aucun échantillon n'a été trouvé";
            }
		}
 	?>



</div>



