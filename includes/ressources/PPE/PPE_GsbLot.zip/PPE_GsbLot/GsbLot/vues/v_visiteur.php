<?php

    echo '<div class="title">Visiteur
            <div class="connected">Vous êtes connecté en tant que : 
            '.$DonneesUtil['prenomUtilisateur'].' '.$DonneesUtil['nomUtilisateur'].'</div>
        </div>';

?>
<div class="content">
    <a href="index.php?uc=visiteur&action=VisiteurLot">
        <img src="includes/images/visiteur_visite.jpg">
        <div class="button">Renseigner date et medecin des échantillons laissés</div>
    </a>
    <a href="index.php?uc=visiteur&action=ConsultationEchantillons">
        <img src="includes/images/visiteur_magasin.jpg">
        <div class="button">Consulter les échantillons</div>
    </a>
</div>
<a href="index.php?uc=deconnexion">
    <div class="deco button">Déconnexion</div>
</a>