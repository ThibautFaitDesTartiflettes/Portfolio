<?php
    if (empty($ConsulterDate)) {
        $message = "Aucun lot pour la date : ".$_POST['calendrier']."";
        $redirection = "index.php?uc=production&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }
    else {
        echo '<div class="title">Lots pour la date : '.$_POST['calendrier'].'</div>';
        echo '<table>
                <tr>
                    <td>Numéro</td>
                    <td>Fabrication</td>
                    <td>Nombre échantillon</td>
                </tr>';
            foreach ($ConsulterDate as $info) {
                echo '<tr>
                        <td>'.$info['numLot'].'</td>
                        <td>'.$info['dateFabricationLot'].'</td>
                        <td>'.$info['nb_echantillon'].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=production&action=consulter"><div class="button">Retour</div></a>';
    }
?>