<div class="title">Renseignement date et visiteur</div>
<br/>
<form method="POST" action="index.php?uc=magasin&action=validation">
    <div class="libelle">
        <span>Date d'attribution : </span><br/>
        <span>Médicament : </sapn><br/>
        <span>Visiteur : </span><br/>
        <span>Nombre d'échantillon sortis : </span><br/>
    </div>
    <div class="saisie">
        <input type="date" name="calendrier">
        <br/>
        <?php

            echo '<select name="Medicament">';
                    
            foreach ($DonneesMedoc as $Medoc) {

                echo '<option value="'.$Medoc['numMedicament'].'">'.$Medoc['nomMedicament'].'</option>';
            }

            echo '</select>';

        ?>
        </br>
        <?php

            echo '<select name="Visiteur">';
        
            foreach ($DonneesVisiteur as $Visiteur) {

                echo '<option value="'.$Visiteur['idUtilisateur'].'">'.$Visiteur['nomUtilisateur'].' '.$Visiteur['prenomUtilisateur'].'</option>';
            }

            echo '</select>';

        ?>
        <br/>
        <input type="number" name="nbEchantillon" min="0">
    </div>
    <div class="formBt">
        <input type="submit" value="Enregistrer" class="connectBt">
    </div>
</form>
<a href="index.php?uc=magasin&action=afficher"><div class="button deco">Retour</div></a>