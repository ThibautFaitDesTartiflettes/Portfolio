<?php
    if (empty($ConsulterNum)) {
        $message = "Aucun lot pour : ".$Medicament."";
        $redirection = "index.php?uc=production&action=consulter";
        $couleur = "red";
        require "vues/v_validation.php";
    }
    else {
        echo '<div class="title">Lots pour la médicament : '.$Medicament.'</div>';
        echo '<table>
                <tr>
                    <td>Numéro</td>
                    <td>Fabrication</td>
                    <td>Nombre échantillon</td>
                </tr>';
            foreach ($ConsulterNum as $info) {
                echo '<tr>
                        <td>'.$info['numLot'].'</td>
                        <td>'.$info['dateFabricationLot'].'</td>
                        <td>'.$info['nb_echantillon'].'</td>
                    </tr>';
            }
        echo '</table>
        <a href="index.php?uc=production&action=consulter"><div class="button">Retour</div></a>';
    }
?>