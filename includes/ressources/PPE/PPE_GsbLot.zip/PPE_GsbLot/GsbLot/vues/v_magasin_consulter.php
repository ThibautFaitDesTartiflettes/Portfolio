<div class="title">Consulter les échantillons</div>
<br/>
<div class = "consulterMedoc">
    <h3>Consulter le stock</h3>
    <form method="POST" action="index.php?uc=magasin&action=consulterStock">
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<br/><br/><br/>
<div class="consulterMedoc">
    <h3>Consulter par Médicament</h3>
    <br/>
    <form method="POST" action="index.php?uc=magasin&action=consulterMedoc">
        <span>Médicament : </span>
        <select name="Medicament">
            <?php
                foreach ($DonneesMedoc as $Medoc) {
                    echo '<option value="'.$Medoc['numMedicament'].'">'.$Medoc['nomMedicament'].'</option>';
                }
            ?>
        </select>
        <br/>
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<br/><br/><br/>
<div class="consulterDate">
    <h3>Consulter par Date</h3>
    <br/>
    <form method="POST" action="index.php?uc=magasin&action=consulterDate">
        <span>Sélectioner une date : </span>
        <input type="date" name="calendrier">
        <br/>
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<br/><br/><br/>
<div class="consulterMedoc">
    <h3>Consulter par Visiteur</h3>
    <br/>
    <form method="POST" action="index.php?uc=magasin&action=consulterVisiteur">
        <span>Visiteur : </span>
        <select name="visiteur">
        <?php
                foreach ($DonneesVisiteur as $Visiteur) {
                    echo '<option value="'.$Visiteur['idUtilisateur'].'">'.$Visiteur['nomUtilisateur'].' '.$Visiteur['prenomUtilisateur'].'</option>';
                }
            ?>
        </select>
        <br/>
        <input type="submit" value="Consulter" class="connectBt">
    </form>
</div>
<a href="index.php?uc=magasin&action=afficher"><div class="button deco">Retour</div></a>