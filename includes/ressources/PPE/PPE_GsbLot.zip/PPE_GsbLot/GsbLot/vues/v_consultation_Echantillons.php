<div class="title">
	Consultation échantillons
</div>



<form method ="post">
	<input  class="inputText" type="submit" value="Date" formaction="index.php?uc=visiteur&action=EnchDate">
	<input  class="inputText" type="submit" value="Médicament" formaction="index.php?uc=visiteur&action=EnchMed">
	<input  class="inputText"  type="submit" value="Médecin" formaction="index.php?uc=visiteur&action=EnchMedecin">
	<input class="button deco" type="submit" value="Retour" formaction="index.php?uc=visiteur">
</form>

