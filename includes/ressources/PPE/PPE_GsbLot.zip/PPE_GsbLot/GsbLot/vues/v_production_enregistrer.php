<div class="title">Enregistrer un lot</div>
<br/>
<form method="POST" action="index.php?uc=production&action=validation">
    <div class="libelle">
        <span>Numéro du lot : </span><br/>
        <span>Date du lot : </sapn><br/>
        <span>Médicament : </span><br/>
        <span>Nombre d'échantillon : </span><br/>
    </div>
    <div class="saisie">
        <input type="number" name="Lot" min="0">
        <br/>
        <input type="date" name="calendrier">
        <br/>
        <?php

            echo '<select name="Medicament">';
                    
            foreach ($DonneesMedoc as $Medoc) {

                echo '<option value="'.$Medoc['numMedicament'].'">'.$Medoc['nomMedicament'].'</option>';
            }

            echo '</select>';

        ?>
        <br/>
        <input type="number" name="nbEchantillon" min="0">
    </div>
    <div class="formBt">
        <input type="submit" value="Enregistrer" class="connectBt">
    </div>
</form>
<a href="index.php?uc=production&action=afficher"><div class="button deco">Retour</div></a>