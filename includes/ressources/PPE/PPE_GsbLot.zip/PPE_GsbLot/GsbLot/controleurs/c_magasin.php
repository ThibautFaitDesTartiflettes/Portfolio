<?php

if (!isset($_REQUEST['action'])) {
    $action = "afficher";
}
else {
    $action = $_REQUEST['action'];
}

switch ($action)
{
    case "afficher" : {
        $DonneesUtil = getDonneesUtil($_SESSION['id']);
        require "vues/v_magasin_afficher.php";
    break;
    }

    case "renseigner" : {
        $DonneesMedoc = getDonneesMedicament();
        $DonneesVisiteur = getDonneesVisiteur();
        require "vues/v_magasin_renseigner.php";
    break;
    }

    case "consulter" : {
        $DonneesMedoc = getDonneesMedicament();
        $DonneesVisiteur = getDonneesVisiteur();
        require "vues/v_magasin_consulter.php";
    break;
    }

    case "consulterMedoc" : {
        $Medicament = getNomMedicament($_POST['Medicament']);
        $ConsulterParMedoc = getEchantillionMedoc($_POST['Medicament']);
        require "vues/v_magasin_consulterMedoc.php";
    break;
    }

    case "consulterDate" : {
        $ConsulterDateSortie = getEchantillonDateSortie($_POST['calendrier']);
        require "vues/v_magasin_consulterDate.php";
    break;
    }

    case "consulterVisiteur" : {
        $Visiteur = getNomVisiteur($_POST['visiteur']);
        $ConsulterParVisiteur = getEchantillonVisiteur($_POST['visiteur']);
        require "vues/v_magasin_consulterVisiteur.php";
    break;
    }

    case "consulterStock" : {
        $ConsulterLeStock = getConsultationStock();
        require "vues/v_magasin_consulterStock.php";
    break;
    }

    case "validation" : {

     
       
        
        $nb = getTotalEchantillonsDispo($_POST['Medicament'])['totalEchant'];

  
        if ($nb < $_POST['nbEchantillon'] ) {
            $message = "Le nombre d'échantillon en magasin est inférieur à la demande";
            $redirection = "index.php?uc=magasin&action=renseigner";
            $couleur = "red";
        }
        else {
           
            $minlot = getMinLot($_REQUEST["Medicament"]);
            $minlot = 0;
            $int = $_REQUEST["nbEchantillon"];

           
            for ($i=0; $i < $int ; $i++) { 
       
                //updateEchantillonMagasin($minlot[$i]["numLot"],$minlot[$i]["numEchantillon"],$_REQUEST["calendrier"],$_REQUEST["Visiteur"]);
            }

            if ($_REQUEST["calendrier"] != "" && $_REQUEST["nbEchantillon"] != "") {
                $message = "Les données ont bien été enregistrés";
                $redirection = "index.php?uc=magasin&action=afficher";
                $couleur = "green";
            }
            else{
                $message = "Les données n'ont pas été enregistrés suite à un manque d'échantillon. Veuillez réessayer.";
                $redirection = "index.php?uc=magasin&action=renseigner";
                $couleur = "red";
            }
        }
    require "vues/v_validation.php";
    break;
    }
}
?>
