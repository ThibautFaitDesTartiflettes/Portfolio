<?php


    if (isset($_REQUEST['action'])) 
    {
        $action = $_REQUEST['action'];
    }
    else{
        $action = "afficher";
    }


    switch ($action)
    {

        case "afficher" : {  
            $DonneesUtil = getDonneesUtil($_SESSION['id']);
            include "vues/v_visiteur.php"; 
            break ;
        }
        case "VisiteurLot" : {  
           
            $LesMedecins = getLesMedecins();
            $LesMedicaments = getDonneesMedicament();
            $lst = array(count($_POST));
            $rediriger = false;
            
            foreach ($_POST as $key => $value){
                if(substr($key,0,2) == "cb"){
                    $string = substr($key,2,99);
                    
                    $arrayV = explode('*',$string);
               
                    updateEchantillonVisiteur($arrayV[0], $arrayV[1],$_REQUEST["Date"],$_REQUEST["Medecin"]);
                    $rediriger = true;
                }
              
            }

            if( $rediriger ){
                $couleur ="green";
                $message=" échantillon mis à jour";
                $redirection = "index.php?uc=visiteur";
                include "vues/v_validation.php"; 
               

            }
            else{
                include "vues/v_visiteur_Lot.php"; 
            }
            
            break ;
        }

        case "ConsultationEchantillons" : {  
            
            include "vues/v_consultation_Echantillons.php"; 
            break ;
        }

        case "EnchDate": {
            include "vues/v_consultation_Echantillons.php"; 
            include "vues/v_consultation_echantillons_date.php"; 
            break ;
        }

        case "EnchMed": {
            $LesMedicaments = getDonneesMedicament();
            include "vues/v_consultation_Echantillons.php"; 
            include "vues/v_consultation_echantillons_medicaments.php"; 
            break ;
        }

        case "EnchMedecin": {
            $LesMedecins = getLesMedecins();
            include "vues/v_consultation_Echantillons.php"; 
            include "vues/v_consultation_echantillons_medecin.php"; 
            break ;
        }

    }



?>
