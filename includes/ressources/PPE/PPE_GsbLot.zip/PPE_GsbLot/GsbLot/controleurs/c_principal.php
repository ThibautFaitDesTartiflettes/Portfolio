<?php
if (isset($_REQUEST['uc']))
{

	switch ($_REQUEST['uc'])
	{
		case 'auth' : {  include "c_authentification.php" ; break ;} 
		case 'magasin' : {  include "c_magasin.php" ; break ;} 	
        case 'production' : {  include "c_production.php" ; break ;}
        case 'visiteur' : {  include "c_visiteur.php" ; break ;}
		case 'deconnexion' : {  include "includes/modele/deconnexion.php"; break;}
	}
}
?>


