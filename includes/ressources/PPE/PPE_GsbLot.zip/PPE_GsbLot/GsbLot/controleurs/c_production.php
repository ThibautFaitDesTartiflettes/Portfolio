<?php

if (!isset($_REQUEST['action'])) {
    $action = "afficher";
}
else {
    $action = $_REQUEST['action'];
}

switch ($action)
{
    case "afficher" : {
        $DonneesUtil = getDonneesUtil($_SESSION['id']);
        require "vues/v_production_afficher.php";
    break;
    }

    case "enregistrer" : {
        $DonneesMedoc = getDonneesMedicament();
        require "vues/v_production_enregistrer.php";
    break;
    }

    case "consulter" : {
        $DonneesMedoc = getDonneesMedicament();
        require "vues/v_production_consulter.php";
    break;
    }

    case "consulterMedoc" : {
        $Medicament = getNomMedicament($_POST['Medicament']);
        $ConsulterNum = getLotMedoc($_POST['Medicament']);
        require "vues/v_production_consulterMedoc.php";
    break;
    }

    case "consulterDate" : {
        $ConsulterDate = getLotDate($_POST['calendrier']);
        require "vues/v_production_consulterDate.php";
    break;
    }

    case "validation" : {

        if (!empty(existeLot($_POST['Lot']))) {
            $message = "Le lot existe déjà, veuillez changer le numéro";
            $redirection = "index.php?uc=production&action=enregistrer";
            $couleur = "red";
        }
        else {
            $insertionLot = ajouterLot($_POST['Lot'], $_POST['calendrier'], $_POST['Medicament']);

            for ($i = 1; $i <= $_POST['nbEchantillon']; $i++) {
                $insertionEchant = ajouterEchantillon($i, $_POST['Lot']);
            }

            if (!empty($insertionLot) && !empty($insertionEchant)) {
                $message = "Le lot et les échantillons a été ajouté";
                $redirection = "index.php?uc=production&action=afficher";
                $couleur = "green";
            }
            else{
                $message = "Le lot et les échantillosn n'ont pas été ajouté, veuillez recommencer";
                $redirection = "index.php?uc=production&action=enregistrer";
                $couleur = "red";
            }
        }
    require "vues/v_validation.php";
    break;
    }
}

?>
