<?php

if (isset($_REQUEST['action'])) 
{
    $action = $_REQUEST['action'];
    switch ($action)
    {
        case "verif" :    {   

            $login = $_REQUEST['login'];
            $mdp = md5($_REQUEST['mdp']);    

            $result= verifierIdentification($login, $mdp) ;

            if ($result)    
            {

                if ($_SESSION['type']=="prod")
                {

                    header ("Location:index.php?uc=production") ; 
                }
                else if ($_SESSION['type']=="magasin")
                {
                    header ("Location:index.php?uc=magasin") ; 
                }
                else{
                    header ("Location:index.php?uc=visiteur") ; 
                }
            }
            else 
            {
                $_SESSION['error'] = "Identification incorrecte";
                header ("Location:index.php") ;
            }
            break ;

            }
    }
}
?>
