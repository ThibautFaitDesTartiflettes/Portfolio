<?php
function verifierIdentification($loginSaisi,$mdpSaisi) {
    require "connexion.php" ;
    $sql="select * from gsblot_utilisateur";
    $exec=$bdd->query($sql);
    $trouve = false ;
    $fin=false ;
    while (!$trouve && !$fin)
    {
        if ($ligne = $exec->fetch())
        {

            if ($ligne['loginUtilisateur']==$loginSaisi && $ligne['mdpUtilisateur']==$mdpSaisi)
            {
                $trouve = true ;
                $_SESSION['id']=$ligne['idUtilisateur'] ;
                $_SESSION['type']=$ligne['typeUtilisateur'] ;
            }
        }
        else
        {
            $fin = true ;
        }
    }
    return $trouve ;
}

function getDonneesUtil($id) {
    require "connexion.php";
    $sql = "SELECT * FROM gsblot_utilisateur WHERE idUtilisateur = ".$id."";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch();
    return $curseur;
}

function getDonneesMedicament() {
    require "connexion.php";
    $sql = "SELECT * FROM gsblot_medicament";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getDonneesVisiteur(){
    require "connexion.php";
    $sql = "SELECT * FROM gsblot_utilisateur Where typeUtilisateur = 'visiteur'";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getLesMedecins(){
    require "connexion.php";
    $sql = "select * from gsblot_medecin";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}


function getLesMedicamentSortie($medoc){
    require "connexion.php";
    $sql = "select  L.numlot as lot,numEchantillon
        from gsblot_lot L
        inner join gsblot_echantillon E on L.numLot =  E.numLot
        where E.dateVisite is null
        and E.dateSortie is not null
        and L.numMedicament = {$medoc}  
        order by L.numlot";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function existeLot($numLot) {
    require "connexion.php";
    $sql = "SELECT numLot from gsblot_lot WHERE numLot = ".$numLot."";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch();
    return $curseur['numLot'];

}

function ajouterLot($numLot, $dateFabrication, $numMedoc) {
    require "connexion.php" ;
    $sql = "INSERT INTO gsblot_lot(numLot, dateFabricationLot, numMedicament) VALUES (".$numLot.",'".$dateFabrication."',".$numMedoc.")" ;
    $exec=$bdd->prepare($sql) ;
    $resultat = $exec->execute() ;
    return $resultat;
}

function ajouterEchantillon($numEchant, $numLot) {
    require "connexion.php" ;
    $sql = "INSERT INTO gsblot_echantillon(numEchantillon, numLot) VALUES (".$numEchant.",".$numLot.")" ;
    $exec=$bdd->prepare($sql) ;
    $resultat = $exec->execute();
    return $resultat;
}

function getNomMedicament($numMedoc) {
    require "connexion.php";
    $sql = "SELECT nomMedicament from gsblot_medicament WHERE numMedicament = ".$numMedoc."";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch();
    return $curseur['nomMedicament'];
}

function getLotMedoc($numMedoc) {
    require "connexion.php";
    $sql = "SELECT gsblot_lot.numLot, dateFabricationLot, COUNT(*) as nb_echantillon
            FROM gsblot_lot
            INNER JOIN gsblot_echantillon ON gsblot_echantillon.numLot = gsblot_lot.numLot
            WHERE numMedicament = ".$numMedoc."
            GROUP BY gsblot_lot.numLot, dateFabricationLot";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getLotDate($date) {
    require "connexion.php";
    $sql = 'SELECT gsblot_lot.numLot, dateFabricationLot, COUNT(*) as nb_echantillon
            FROM gsblot_lot
            INNER JOIN gsblot_echantillon ON gsblot_echantillon.numLot = gsblot_lot.numLot
            GROUP BY gsblot_lot.numLot, dateFabricationLot
            HAVING dateFabricationLot = "'.$date.'"';
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function updateEchantillonVisiteur($numLot,$numEchantillon,$date,$numMedecin){
    require "connexion.php";
    $sql ="update gsblot_echantillon set dateVisite = '{$date}' , numMedecin = {$numMedecin}
    where numLot = {$numLot} and numEchantillon = {$numEchantillon}
    ";
    
    $exec=$bdd->prepare($sql) ;
    $exec->execute();
}

function updateEchantillonMagasin($numLot,$numEchantillon,$date,$idUtilisateur){
    require "connexion.php";
    $sql ="update gsblot_echantillon set dateSortie = '{$date}' , idUtilisateur = {$idUtilisateur}
    where numLot = {$numLot} and numEchantillon = {$numEchantillon}
    ";
    
    $exec=$bdd->prepare($sql) ;
    $exec->execute();
    }

function getTotalEchantillonsDispo($numMedicament) {
    require "connexion.php";
    $sql = "SELECT Count(*) as totalEchant 
            FROM gsblot_echantillon
            INNER JOIN gsblot_lot On gsblot_echantillon.numLot = gsblot_lot.numLot
            Where numMedicament = {$numMedicament}
            And dateSortie is null
            and idUtilisateur is null";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch();
    return $curseur;
}

function getEchantillonDate($date){
    require "connexion.php";
    $sql = "SELECT *
    from gsblot_echantillon E
    inner join gsblot_utilisateur U on U.idUtilisateur = E.idUtilisateur
    inner join gsblot_lot L on L.numLot = E.numLot
    inner join gsblot_medicament M on M.numMedicament = L.numMedicament
    where E.dateVisite =  '{$date}' ";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;

}

function getEchantillonMedicament($id){
    require "connexion.php";
    $sql = "SELECT *
    from gsblot_echantillon E
    inner join gsblot_utilisateur U on U.idUtilisateur = E.idUtilisateur
    inner join gsblot_lot L on L.numLot = E.numLot
    inner join gsblot_medicament M on M.numMedicament = L.numMedicament
    inner join gsblot_medecin Med on Med.numMedecin = E.numMedecin
    where M.numMedicament = '{$id}' ";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;

}

function getEchantillonMedecin($id){
    require "connexion.php";
    $sql = "SELECT *
    from gsblot_echantillon E
    inner join gsblot_utilisateur U on U.idUtilisateur = E.idUtilisateur
    inner join gsblot_lot L on L.numLot = E.numLot
    inner join gsblot_medicament M on M.numMedicament = L.numMedicament
    inner join gsblot_medecin Med on Med.numMedecin = E.numMedecin
    where E.numMedecin = '{$id}' ";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;

}

function getEchantillonDateMagasin($date){
    require "connexion.php";
    $sql = "SELECT *
    FROM gsblot_echantillon
    inner join gsblot_utilisateur on gsblot_echantillon.idUtilisateur = gsblot_utilisateur.idUtilisateur
    inner join gsblot_lot on gsblot_echantillon.numLot = gsblot_lot.numLot
    inner join gsblot_medicament on gsblot_echantillon.numMedicament = gsblot_medicament.numMedicament
    where dateSortie = '{$date}' ";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}


function getMinLot($medicament){
    require "connexion.php";
    $sql = "SELECT E.numLot, E.numEchantillon 
    FROM gsblot_echantillon E
    INNER JOIN gsblot_lot L on L.numLot = E.numLot
    where numMedicament = {$medicament}
    And dateSortie is null
    And idUtilisateur is null";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getEchantillionMedoc($numMedoc) {
    require "connexion.php";
    $sql = "SELECT nomUtilisateur, prenomUtilisateur, dateSortie
            FROM gsblot_echantillon
            INNER JOIN gsblot_utilisateur ON gsblot_echantillon.idUtilisateur = gsblot_utilisateur.idUtilisateur
            INNER JOIN gsblot_lot ON gsblot_echantillon.numLot = gsblot_lot.numLot
            WHERE numMedicament = $numMedoc";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getEchantillonDateSortie($date) {
    require "connexion.php";
    $sql = "SELECT nomUtilisateur, prenomUtilisateur, nomMedicament
            FROM gsblot_echantillon
            INNER JOIN gsblot_utilisateur ON gsblot_echantillon.idUtilisateur = gsblot_utilisateur.idUtilisateur
            INNER JOIN gsblot_lot ON gsblot_echantillon.numLot = gsblot_lot.numLot
            INNER JOIN gsblot_medicament ON gsblot_medicament.numMedicament = gsblot_lot.numMedicament
            WHERE dateSortie = '{$date}'";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getEchantillonVisiteur($id) {
    require "connexion.php";
    $sql = "SELECT dateSortie , nomMedicament
            FROM gsblot_echantillon
            INNER JOIN gsblot_lot ON gsblot_echantillon.numLot = gsblot_lot.numLot
            INNER JOIN gsblot_medicament ON gsblot_medicament.numMedicament = gsblot_lot.numMedicament
            WHERE idUtilisateur = $id";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}

function getNomVisiteur($idUtilisateur) {
    require "connexion.php";
    $sql = "SELECT nomUtilisateur, prenomUtilisateur from gsblot_Utilisateur WHERE idUtilisateur = $idUtilisateur";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetch();
    return $curseur['nomUtilisateur'].'  '.$curseur['prenomUtilisateur'];
}

function getConsultationStock(){
    require "connexion.php";
    $sql = "SELECT gsblot_lot.numLot, numEchantillon, nomMedicament
    FROM gsblot_echantillon 
    INNER JOIN gsblot_lot on gsblot_lot.numLot = gsblot_echantillon.numLot
    INNER JOIN gsblot_medicament on gsblot_lot.numMedicament = gsblot_medicament.numMedicament
    And dateSortie is null
    And idUtilisateur is null";
    $exec=$bdd->prepare($sql) ;
    $exec->execute() ;
    $curseur=$exec->fetchAll();
    return $curseur;
}
?>