<br>
 <center style ="margin-bottom: 50px;">
<h1>Selection de la periode</h1>

<form method="POST" action="index.php?uc=cout_impr">
 
 Heure de debut <input type="time" name="min" value="00:00"> <br> <br>

 Heure de fin <input type="time" name="max" value="00:00">  <br><br>

Date de debut <input type="date" name="datemin" value="2013-11-02">  <br><br>

 Date de fin  <input type="date" name="datemax" value="2013-11-02"> <br><br>

<INPUT type="submit" value="Valider" name="submit" class = "button2"> 


</form>
</center>