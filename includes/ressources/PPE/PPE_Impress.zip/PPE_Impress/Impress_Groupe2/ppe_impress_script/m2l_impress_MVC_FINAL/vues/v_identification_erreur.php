<?php
echo '
<!-- CONTENT -->
<p><strong>Erreur ! identifiant ou mot de passe incorrects</p>
				</div>
				</div>
				<div id="right_part">
				</div>
  <!-- CONTENT END -->
 ' ;
?>