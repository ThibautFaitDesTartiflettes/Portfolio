<?php
$bdd = new PDO('mysql:host=localhost;dbname=impress', 'root', '');       
?>