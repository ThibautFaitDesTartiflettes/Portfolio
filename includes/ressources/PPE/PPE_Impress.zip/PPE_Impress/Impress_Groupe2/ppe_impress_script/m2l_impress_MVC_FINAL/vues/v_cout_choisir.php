<h1>Consultation des coûts</h1>

<form action="index.php?uc=cout_impr" method="post">
  <div>
    <input type='submit' name='btPeriph' value='Coût par PERIPHERIQUE' class="buttonPERSO"/>
    <input type='submit' name='btLigue' value='Coût par LIGUE'class="buttonPERSO"/>
    <input type='submit' name='btDate' value='Coût par DATE'class="buttonPERSO"/>
  </div>
</form>

<br>