  <!-- FOOTER -->
  <div id="footer"> Happy &copy; 2013 <a href="#" > Tous droits r&eacute;serv&eacute;s</a> 
    
  </div>
  <!-- FOOTER END -->
</div>
</body>
</html>