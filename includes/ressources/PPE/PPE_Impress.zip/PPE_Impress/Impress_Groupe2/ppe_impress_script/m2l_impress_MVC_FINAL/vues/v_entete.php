<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!--<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2" />
<link rel="stylesheet" media="screen" type="text/css" title="css" href="style.css"/>

<style type="text/css">
<!--
#holder #header #img p {
	color: #C12A31;
}
#holder #header #img p br {
	font-weight: bold;
}
#holder #header #img p {
	font-weight: bold;
}
-->
</style>
</head>
<body>
<div id="body">
 <div id="holder">																																																																																																																																																																																																																																																																																																																				
  <!-- HEADER -->
  <div id="header">
    <div id="img">
      <p><br />
        Maison des Ligues de Lorraine<br />
        <span> </span></p>
    </div>
    <div id="logo"><a href="#">INTRANET IMPRESS<br />
      <span id="slogan">Consultation des impressions photocopieurs et imprimantes</span></a> </div>
  </div>
  <div class="clear"></div>