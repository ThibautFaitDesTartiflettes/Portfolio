<?php

$PARAM_hote='stadjutodmbd02.mysql.db'; // le chemin vers le serveur
$PARAM_port='';
$PARAM_nom_bd='stadjutodmbd02'; // le nom de votre base de donn�es
$PARAM_utilisateur='stadjutodmbd02'; // nom d'utilisateur pour se connecter
$PARAM_mot_passe='itiNeris02'; // mot de passe de l'utilisateur pour se connecter

try
{
    $bdd = new PDO('mysql:host='.$PARAM_hote.';dbname='.$PARAM_nom_bd, $PARAM_utilisateur, $PARAM_mot_passe);
    $bdd->exec("SET CHARACTER SET utf8");
}
 
catch(Exception $e)
{
        echo 'Erreur : '.$e->getMessage().'<br />';
        echo 'N° : '.$e->getCode();
}
?>
