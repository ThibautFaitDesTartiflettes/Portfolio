
<div class="home">     
    <form method="POST" action ="index.php?uc=gestion&action=AjouterFormule" >
        <input type="submit" class="btn btn-info connectbt" value="Ajouter une formule">
    </form>

    <table id ="tableau">
       
        <?php

            echo '<tr>'                        
            . '<th>Formules</th>'    
            . '<th>Prix</th>'                                       
            . '</tr>' ;

            foreach($lesFormules as $laFormule){

                if(!isset($modif) || $modif != $laFormule['id'] ){
                    echo '<tr>'
                    . '<td>'.$laFormule['designationFormule'].'</td>'
                    . '<td>'.$laFormule['Prix'].' €</td>'
                    . '
                    <form  method="POST">';
                 
                    echo '<td><input type="submit" class="btn btn-info connectbt" value="Modifier"  formaction="index.php?uc=gestion&action=modifFormule&id='.$laFormule['id'].'"></td>';
                    if(!getExisteCommandeFormule( $laFormule['id'])){
                        echo '<td><input type="submit" class="btn btn-info connectbt" value="Supprimer" formaction="index.php?uc=gestion&action=supprFormule&id='.$laFormule['id'].'"></td>'; 
                    }
                    echo '</form>'
                    .'</tr>';
                }
                else{
                    echo '<tr>'
                    .'<form  method="POST">'
                    . '<td><input  type="text" class="input_text2" name="nomFormule" value ="'.$laFormule['designationFormule'].'" size=20></td>'
                    . '<td><input  type="number" class="input_text2" name="prixFormule" value ="'.$laFormule['Prix'].'" size=20>€</td>'
                    . '
                    
                    <td><input type="submit" class="btn btn-info connectbt" value="Valider"  formaction="index.php?uc=gestion&action=validModifFormule&id='.$laFormule['id'].'"></td>
                    </form>'             
                    .'</tr>' ;
                }
           




            }



        ?>

    </table>
</div>
