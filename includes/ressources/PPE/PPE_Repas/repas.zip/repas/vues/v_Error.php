<div class="home">    

<?php 

    if(!$Error){
        echo'<form style="Color:green;" method="POST" action='.$redirection.'>';
    }
    else{
        echo'<form style="Color:red;" method="POST" action='.$redirection.'>';
    }
    echo $Message.'
    <input type="submit" class="btn btn-info connectbt" value="Retour">
    </form>';

    


?>
</div>
