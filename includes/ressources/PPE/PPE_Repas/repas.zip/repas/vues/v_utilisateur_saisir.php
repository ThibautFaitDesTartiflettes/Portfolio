<div class="home">
          
          <div id="Home_title_ss">
              <br /><br />
              <?php
              echo '<h1>Ajouter un nouveau Utilisateur </h1><br /><br />' ;
              echo '<br></br>';
              ?>
              <FORM method="POST" action="index.php?uc=gestion&action=validSaisie">

              <INPUT class="input_text2" type=text name="Nom" size="22" maxlength="22" placeholder="Nom"> <br> <br>
              <INPUT class="input_text2" type=text name="Prenom" size="22" maxlength="22" placeholder="Prénom"><br> <br>
              <INPUT class="input_text2" type=text name="IdClasse" size="22" maxlength="22" placeholder="Identifiant de la classe"><br> <br>
              <INPUT class="input_text2" type=text name="Login" size="22" maxlength="22" placeholder="Nom d'utilisateur"><br> <br>
              <INPUT class="input_text2" type="password" name="Mdp" size="22" maxlength="22" placeholder="Mot de passe"><br> <br>
              <select class="input_text2" name="Statut">
              <option value="NULL"> -Choisissez un statut- </option>
              <option value=1> 1 </option>
              <option value=2> 2 </option>
              </select><br> <br>

              <input type="submit" class="btn btn-info connectbt" value="Ajouter">

              </FORM>
          </div>




