<?php
echo '
  <div id="content">
    <div id="left">
      <div>
        <h1>Choisir Utilisateur</h1>
        <form method="post" action="index.php?uc=gestion&action=utilisateur">
          <fieldset>
          Utilisateur :
		  <select name="nom">
		  <option value="0">' ;
		  foreach($execLesEtudiants as $unEtudiant) {
			  echo '<option value="'.$unEtudiant['nom'].'">'.$unEtudiant['prenom'] ;
		  }
		  
		  echo '</select>
		  		<input type="button" value="OK" name="button" class="button" onclick="submit()"/>
		  		</form>

      </div>
    </div>
    <div class="clear"></div>
 ' ;
?>