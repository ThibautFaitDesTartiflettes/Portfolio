
<div class="home">   
    <form method="POST"  action ="index.php?uc=gestion&action=CheckError">
        Designation de la nouvelle formule :
        <input  type="text" class="input_text2" name="nomFormule" value ="" size=20>
        <br>
        Prix de la nouvelle formule :
        <input  type="number" class="input_text2" name="PrixFormule" value =0 size=20>
        <br>
        <br>
        <input type="submit" class="btn btn-info connectbt" value="Ajouter">
    </form>

</div>
00