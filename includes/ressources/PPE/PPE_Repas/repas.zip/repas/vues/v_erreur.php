
      <div class="home">
          <div id="Home_title_ss">
              <div id="Home_title_struct">
                  <?php echo $message ; ?>
              </div>             
          </div>
      </div>