<div class="home">
          
          <div id="Home_title_ss">
              <br /><br />
              <?php
              echo '<div id="Titles">'.$_SESSION['ident']."</div>";
              echo 'Que voulez-vous modifier ?<br /><br />' ;
              ?>
          </div>


    <FORM method="POST" action="index.php?uc=gestion">

    <INPUT type=hidden name="Oldid" size="22" maxlength="22" value = "<?php echo $id ?>">
    <INPUT type=text name="Id" size="22" maxlength="22" value = "<?php echo $id ?>"> Identifiant <br> <br>
    <INPUT type=text name="Nom" size="22" maxlength="22" value = "<?php echo $nom ?>"> Nom <br> <br>
    <INPUT type=text name="Prenom" size="22" maxlength="22" value = "<?php echo $prenom ?>"> Prenom <br> <br>
    <INPUT type=text name="IdClasse" size="22" maxlength="22" value = "<?php echo $idClasse ?>"> Identifiant de la classe <br> <br>
    <INPUT type=text name="Login" size="22" maxlength="22" value = "<?php echo $login ?>"> Nom d'utilisateur <br> <br>
    <INPUT type=text name="Mdp" size="22" maxlength="22" value = "<?php echo $mdp ?>"> Mot de passe <br> <br>
    <INPUT type=text name="Credit" size="22" maxlength="22" value = "<?php echo $credit ?>"> CreditRepas <br> <br>


    <INPUT type="submit" value="Modifier l'utilisateur'" name="submit" class = button2> 

    </FORM>

    <br>
    