<div class="home">
          
          <div id="Home_title_ss">
              <br /><br />
              <?php
              echo 'Qui voulez-vous supprimer ?<br /><br />' ;
              echo '<form name="suppression" method="POST" action="index.php?uc=gestion&action=validSupp">';
              echo '<select name="utilisateur">';
              echo '<option value="">-Selectionner un utilisateur-</option>';
                foreach ($utilisateurs as $unUtilisateur) {
                  echo '<option value='.$unUtilisateur['id'].'>'.$unUtilisateur['prenom'].' '.$unUtilisateur['nom'].'</option>';
                }
              echo '</select>';
              echo '<br></br>';
              echo '<input type="submit" class="btn btn-info connectbt" value="Supprimer">
                    </form>';
              ?>
          </div>
</div>
          