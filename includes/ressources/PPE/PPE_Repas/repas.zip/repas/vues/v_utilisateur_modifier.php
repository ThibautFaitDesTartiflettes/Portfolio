<div class="home">
          
        <div id="Home_title_ss">
              <br /><br />
              <?php
              echo 'Que voulez-vous modifier ?<br /><br />' ;
              ?>
              <select name="utilisateur" onchange="chargePageModifierUtilisateur(this.value)">
              <?php
              echo '<option value=-1>-Selectionner un utilisateur-</option>';
                foreach ($utilisateurs as $unUtilisateur) {
                  echo '<option value='.$unUtilisateur['id'].'>'.$unUtilisateur['prenom'].' '.$unUtilisateur['nom'].'</option>';
                }
              echo '</select>';
              echo '<br></br>';
              ?>
        </div>

            <FORM method="POST" action="index.php?uc=gestion&action=validModif">
                <?php
                
                if (!isset($_REQUEST['id'])) {

                    echo '<INPUT type=text name="Nom" size="22" maxlength="22" placeholder="Nom" disabled> <br> <br>
                    <INPUT type=text name="Prenom" size="22" maxlength="22" placeholder="Prénom"  disabled><br> <br>
                    <INPUT type=text name="IdClasse" size="22" maxlength="22" placeholder="Identifiant de la classe" disabled><br> <br>
                    <INPUT type=text name="Login" size="22" maxlength="22" placeholder="Nom d utilisateur" disabled><br> <br>
                    <select class="input_text2" disabled>
                    <option> -Choisissez un statut- </option>
                    <option> 1 </option>
                    <option> 2 </option>
                    </select><br> <br>';
                }
                else{
                    $etudiantSelect = SelectUnEtudiant($_REQUEST['id']);
                   
                    echo '<INPUT type=text name="Nom" class="input_text2" size="22" maxlength="22" value="'.$etudiantSelect['nom'].'"><br> <br>';
                    echo '<INPUT type=text name="Prenom" class="input_text2" size="22" maxlength="22" value="'.$etudiantSelect['prenom'].'"><br> <br>';
                    echo '<INPUT type=text name="IdClasse" class="input_text2" size="22" maxlength="22" value="'.$etudiantSelect['idClasse'].'"><br> <br>';
                    echo '<INPUT type=text name="Login" class="input_text2" size="22" maxlength="22" value="'.$etudiantSelect['login'].'"><br> <br>';
                    echo '<select name="nv_statut" class="input_text2" value="-Choisissez une valeur-">';
                    if ($etudiantSelect['statut'] == 1) {
                        echo '<option value=1> 1 </option>';
                        echo '<option value=2> 2 </option>';
                    }
                    elseif ($etudiantSelect['statut'] == 2) {
                        echo '<option value=2> 2 </option>';
                        echo '<option value=1> 1 </option>';
                    }
                    elseif ($etudiantSelect['statut'] == 4) {
                        echo '<option value=4> 4 </option>';
                        echo '<option value=1> 1 </option>';
                        echo '<option value=2> 2 </option>';
                    }
                    echo '</select>';
                    echo '<br> <br>';
                    $_SESSION['etudiantId'] = $etudiantSelect['id']; 
                }
                ?>
                    <INPUT type="submit" value="Modifier l utilisateur" name="submit" class="btn btn-info connectbt">
            </FORM>
        <br>
</div>