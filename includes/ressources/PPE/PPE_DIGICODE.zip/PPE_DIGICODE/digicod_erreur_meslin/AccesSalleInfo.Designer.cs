﻿namespace digicod_erreur_meslin
{
    partial class AccesSalleInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccesSalleInfo));
            this.ListeVoyant = new System.Windows.Forms.ImageList(this.components);
            this.tbMatricule = new System.Windows.Forms.TextBox();
            this.btnum1 = new System.Windows.Forms.Button();
            this.btnum2 = new System.Windows.Forms.Button();
            this.btnum3 = new System.Windows.Forms.Button();
            this.btnum4 = new System.Windows.Forms.Button();
            this.btnum5 = new System.Windows.Forms.Button();
            this.btnum6 = new System.Windows.Forms.Button();
            this.btnum7 = new System.Windows.Forms.Button();
            this.btnum8 = new System.Windows.Forms.Button();
            this.btnum9 = new System.Windows.Forms.Button();
            this.btlettreA = new System.Windows.Forms.Button();
            this.btlettreB = new System.Windows.Forms.Button();
            this.btlettreC = new System.Windows.Forms.Button();
            this.btlettreD = new System.Windows.Forms.Button();
            this.btlettreE = new System.Windows.Forms.Button();
            this.btlettreF = new System.Windows.Forms.Button();
            this.btlettreG = new System.Windows.Forms.Button();
            this.btlettreH = new System.Windows.Forms.Button();
            this.btlettreI = new System.Windows.Forms.Button();
            this.btlettreJ = new System.Windows.Forms.Button();
            this.btlettreK = new System.Windows.Forms.Button();
            this.btlettreL = new System.Windows.Forms.Button();
            this.btlettreM = new System.Windows.Forms.Button();
            this.btlettreN = new System.Windows.Forms.Button();
            this.btlettreO = new System.Windows.Forms.Button();
            this.btlettreP = new System.Windows.Forms.Button();
            this.btlettreQ = new System.Windows.Forms.Button();
            this.btlettreR = new System.Windows.Forms.Button();
            this.btlettreS = new System.Windows.Forms.Button();
            this.btlettreT = new System.Windows.Forms.Button();
            this.btlettreU = new System.Windows.Forms.Button();
            this.btlettreV = new System.Windows.Forms.Button();
            this.btlettreW = new System.Windows.Forms.Button();
            this.btlettreX = new System.Windows.Forms.Button();
            this.btlettreY = new System.Windows.Forms.Button();
            this.btlettreZ = new System.Windows.Forms.Button();
            this.btCancel = new System.Windows.Forms.Button();
            this.btEnter = new System.Windows.Forms.Button();
            this.btnum0 = new System.Windows.Forms.Button();
            this.pbVoyant = new System.Windows.Forms.PictureBox();
            this.tbMdp = new System.Windows.Forms.TextBox();
            this.lbMatricule = new System.Windows.Forms.Label();
            this.lbMdp = new System.Windows.Forms.Label();
            this.gbDigicode = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbVoyant)).BeginInit();
            this.gbDigicode.SuspendLayout();
            this.SuspendLayout();
            // 
            // ListeVoyant
            // 
            this.ListeVoyant.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ListeVoyant.ImageStream")));
            this.ListeVoyant.TransparentColor = System.Drawing.Color.Transparent;
            this.ListeVoyant.Images.SetKeyName(0, "voyant_vierge.png");
            this.ListeVoyant.Images.SetKeyName(1, "voyant_erreur.png");
            this.ListeVoyant.Images.SetKeyName(2, "voyant_ok.png");
            // 
            // tbMatricule
            // 
            this.tbMatricule.Enabled = false;
            this.tbMatricule.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMatricule.Location = new System.Drawing.Point(15, 40);
            this.tbMatricule.MaxLength = 4;
            this.tbMatricule.Name = "tbMatricule";
            this.tbMatricule.Size = new System.Drawing.Size(129, 39);
            this.tbMatricule.TabIndex = 0;
            this.tbMatricule.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnum1
            // 
            this.btnum1.Location = new System.Drawing.Point(15, 102);
            this.btnum1.Name = "btnum1";
            this.btnum1.Size = new System.Drawing.Size(39, 38);
            this.btnum1.TabIndex = 1;
            this.btnum1.Text = "1";
            this.btnum1.UseVisualStyleBackColor = true;
            this.btnum1.Click += new System.EventHandler(this.btnum1_Click);
            // 
            // btnum2
            // 
            this.btnum2.Location = new System.Drawing.Point(60, 102);
            this.btnum2.Name = "btnum2";
            this.btnum2.Size = new System.Drawing.Size(39, 38);
            this.btnum2.TabIndex = 2;
            this.btnum2.Text = "2";
            this.btnum2.UseVisualStyleBackColor = true;
            this.btnum2.Click += new System.EventHandler(this.btnum2_Click);
            // 
            // btnum3
            // 
            this.btnum3.Location = new System.Drawing.Point(105, 102);
            this.btnum3.Name = "btnum3";
            this.btnum3.Size = new System.Drawing.Size(39, 38);
            this.btnum3.TabIndex = 3;
            this.btnum3.Text = "3";
            this.btnum3.UseVisualStyleBackColor = true;
            this.btnum3.Click += new System.EventHandler(this.btnum3_Click);
            // 
            // btnum4
            // 
            this.btnum4.Location = new System.Drawing.Point(150, 102);
            this.btnum4.Name = "btnum4";
            this.btnum4.Size = new System.Drawing.Size(39, 38);
            this.btnum4.TabIndex = 4;
            this.btnum4.Text = "4";
            this.btnum4.UseVisualStyleBackColor = true;
            this.btnum4.Click += new System.EventHandler(this.btnum4_Click);
            // 
            // btnum5
            // 
            this.btnum5.Location = new System.Drawing.Point(195, 102);
            this.btnum5.Name = "btnum5";
            this.btnum5.Size = new System.Drawing.Size(39, 38);
            this.btnum5.TabIndex = 5;
            this.btnum5.Text = "5";
            this.btnum5.UseVisualStyleBackColor = true;
            this.btnum5.Click += new System.EventHandler(this.btnum5_Click);
            // 
            // btnum6
            // 
            this.btnum6.Location = new System.Drawing.Point(240, 102);
            this.btnum6.Name = "btnum6";
            this.btnum6.Size = new System.Drawing.Size(39, 38);
            this.btnum6.TabIndex = 6;
            this.btnum6.Text = "6";
            this.btnum6.UseVisualStyleBackColor = true;
            this.btnum6.Click += new System.EventHandler(this.btnum6_Click);
            // 
            // btnum7
            // 
            this.btnum7.Location = new System.Drawing.Point(285, 102);
            this.btnum7.Name = "btnum7";
            this.btnum7.Size = new System.Drawing.Size(39, 38);
            this.btnum7.TabIndex = 7;
            this.btnum7.Text = "7";
            this.btnum7.UseVisualStyleBackColor = true;
            this.btnum7.Click += new System.EventHandler(this.btnum7_Click);
            // 
            // btnum8
            // 
            this.btnum8.Location = new System.Drawing.Point(105, 146);
            this.btnum8.Name = "btnum8";
            this.btnum8.Size = new System.Drawing.Size(39, 38);
            this.btnum8.TabIndex = 8;
            this.btnum8.Text = "8";
            this.btnum8.UseVisualStyleBackColor = true;
            this.btnum8.Click += new System.EventHandler(this.btnum8_Click);
            // 
            // btnum9
            // 
            this.btnum9.Location = new System.Drawing.Point(150, 146);
            this.btnum9.Name = "btnum9";
            this.btnum9.Size = new System.Drawing.Size(39, 38);
            this.btnum9.TabIndex = 9;
            this.btnum9.Text = "9";
            this.btnum9.UseVisualStyleBackColor = true;
            this.btnum9.Click += new System.EventHandler(this.btnum9_Click);
            // 
            // btlettreA
            // 
            this.btlettreA.Location = new System.Drawing.Point(15, 221);
            this.btlettreA.Name = "btlettreA";
            this.btlettreA.Size = new System.Drawing.Size(39, 38);
            this.btlettreA.TabIndex = 10;
            this.btlettreA.Text = "A";
            this.btlettreA.UseVisualStyleBackColor = true;
            this.btlettreA.Click += new System.EventHandler(this.btlettreA_Click);
            // 
            // btlettreB
            // 
            this.btlettreB.Location = new System.Drawing.Point(60, 221);
            this.btlettreB.Name = "btlettreB";
            this.btlettreB.Size = new System.Drawing.Size(39, 38);
            this.btlettreB.TabIndex = 11;
            this.btlettreB.Text = "B";
            this.btlettreB.UseVisualStyleBackColor = true;
            this.btlettreB.Click += new System.EventHandler(this.btlettreB_Click);
            // 
            // btlettreC
            // 
            this.btlettreC.Location = new System.Drawing.Point(105, 221);
            this.btlettreC.Name = "btlettreC";
            this.btlettreC.Size = new System.Drawing.Size(39, 38);
            this.btlettreC.TabIndex = 12;
            this.btlettreC.Text = "C";
            this.btlettreC.UseVisualStyleBackColor = true;
            this.btlettreC.Click += new System.EventHandler(this.btlettreC_Click);
            // 
            // btlettreD
            // 
            this.btlettreD.Location = new System.Drawing.Point(150, 221);
            this.btlettreD.Name = "btlettreD";
            this.btlettreD.Size = new System.Drawing.Size(39, 38);
            this.btlettreD.TabIndex = 13;
            this.btlettreD.Text = "D";
            this.btlettreD.UseVisualStyleBackColor = true;
            this.btlettreD.Click += new System.EventHandler(this.btlettreD_Click);
            // 
            // btlettreE
            // 
            this.btlettreE.Location = new System.Drawing.Point(195, 221);
            this.btlettreE.Name = "btlettreE";
            this.btlettreE.Size = new System.Drawing.Size(39, 38);
            this.btlettreE.TabIndex = 14;
            this.btlettreE.Text = "E";
            this.btlettreE.UseVisualStyleBackColor = true;
            this.btlettreE.Click += new System.EventHandler(this.btlettreE_Click);
            // 
            // btlettreF
            // 
            this.btlettreF.Location = new System.Drawing.Point(240, 221);
            this.btlettreF.Name = "btlettreF";
            this.btlettreF.Size = new System.Drawing.Size(39, 38);
            this.btlettreF.TabIndex = 15;
            this.btlettreF.Text = "F";
            this.btlettreF.UseVisualStyleBackColor = true;
            this.btlettreF.Click += new System.EventHandler(this.btlettreF_Click);
            // 
            // btlettreG
            // 
            this.btlettreG.Location = new System.Drawing.Point(285, 221);
            this.btlettreG.Name = "btlettreG";
            this.btlettreG.Size = new System.Drawing.Size(39, 38);
            this.btlettreG.TabIndex = 16;
            this.btlettreG.Text = "G";
            this.btlettreG.UseVisualStyleBackColor = true;
            this.btlettreG.Click += new System.EventHandler(this.btlettreG_Click);
            // 
            // btlettreH
            // 
            this.btlettreH.Location = new System.Drawing.Point(15, 265);
            this.btlettreH.Name = "btlettreH";
            this.btlettreH.Size = new System.Drawing.Size(39, 38);
            this.btlettreH.TabIndex = 17;
            this.btlettreH.Text = "H";
            this.btlettreH.UseVisualStyleBackColor = true;
            this.btlettreH.Click += new System.EventHandler(this.btlettreH_Click);
            // 
            // btlettreI
            // 
            this.btlettreI.Location = new System.Drawing.Point(60, 265);
            this.btlettreI.Name = "btlettreI";
            this.btlettreI.Size = new System.Drawing.Size(39, 38);
            this.btlettreI.TabIndex = 18;
            this.btlettreI.Text = "I";
            this.btlettreI.UseVisualStyleBackColor = true;
            this.btlettreI.Click += new System.EventHandler(this.btlettreI_Click);
            // 
            // btlettreJ
            // 
            this.btlettreJ.Location = new System.Drawing.Point(105, 265);
            this.btlettreJ.Name = "btlettreJ";
            this.btlettreJ.Size = new System.Drawing.Size(39, 38);
            this.btlettreJ.TabIndex = 19;
            this.btlettreJ.Text = "J";
            this.btlettreJ.UseVisualStyleBackColor = true;
            this.btlettreJ.Click += new System.EventHandler(this.btlettreJ_Click);
            // 
            // btlettreK
            // 
            this.btlettreK.Location = new System.Drawing.Point(150, 265);
            this.btlettreK.Name = "btlettreK";
            this.btlettreK.Size = new System.Drawing.Size(39, 38);
            this.btlettreK.TabIndex = 20;
            this.btlettreK.Text = "K";
            this.btlettreK.UseVisualStyleBackColor = true;
            this.btlettreK.Click += new System.EventHandler(this.btlettreK_Click);
            // 
            // btlettreL
            // 
            this.btlettreL.Location = new System.Drawing.Point(195, 265);
            this.btlettreL.Name = "btlettreL";
            this.btlettreL.Size = new System.Drawing.Size(39, 38);
            this.btlettreL.TabIndex = 21;
            this.btlettreL.Text = "L";
            this.btlettreL.UseVisualStyleBackColor = true;
            this.btlettreL.Click += new System.EventHandler(this.btlettreL_Click);
            // 
            // btlettreM
            // 
            this.btlettreM.Location = new System.Drawing.Point(237, 265);
            this.btlettreM.Name = "btlettreM";
            this.btlettreM.Size = new System.Drawing.Size(39, 38);
            this.btlettreM.TabIndex = 22;
            this.btlettreM.Text = "M";
            this.btlettreM.UseVisualStyleBackColor = true;
            this.btlettreM.Click += new System.EventHandler(this.btlettreM_Click);
            // 
            // btlettreN
            // 
            this.btlettreN.Location = new System.Drawing.Point(285, 265);
            this.btlettreN.Name = "btlettreN";
            this.btlettreN.Size = new System.Drawing.Size(39, 38);
            this.btlettreN.TabIndex = 23;
            this.btlettreN.Text = "N";
            this.btlettreN.UseVisualStyleBackColor = true;
            this.btlettreN.Click += new System.EventHandler(this.NbtlettreN_Click);
            // 
            // btlettreO
            // 
            this.btlettreO.Location = new System.Drawing.Point(15, 309);
            this.btlettreO.Name = "btlettreO";
            this.btlettreO.Size = new System.Drawing.Size(39, 38);
            this.btlettreO.TabIndex = 24;
            this.btlettreO.Text = "O";
            this.btlettreO.UseVisualStyleBackColor = true;
            this.btlettreO.Click += new System.EventHandler(this.btlettreO_Click);
            // 
            // btlettreP
            // 
            this.btlettreP.Location = new System.Drawing.Point(60, 309);
            this.btlettreP.Name = "btlettreP";
            this.btlettreP.Size = new System.Drawing.Size(39, 38);
            this.btlettreP.TabIndex = 25;
            this.btlettreP.Text = "P";
            this.btlettreP.UseVisualStyleBackColor = true;
            this.btlettreP.Click += new System.EventHandler(this.btlettreP_Click);
            // 
            // btlettreQ
            // 
            this.btlettreQ.Location = new System.Drawing.Point(105, 309);
            this.btlettreQ.Name = "btlettreQ";
            this.btlettreQ.Size = new System.Drawing.Size(39, 38);
            this.btlettreQ.TabIndex = 26;
            this.btlettreQ.Text = "Q";
            this.btlettreQ.UseVisualStyleBackColor = true;
            this.btlettreQ.Click += new System.EventHandler(this.btlettreQ_Click);
            // 
            // btlettreR
            // 
            this.btlettreR.Location = new System.Drawing.Point(150, 309);
            this.btlettreR.Name = "btlettreR";
            this.btlettreR.Size = new System.Drawing.Size(39, 38);
            this.btlettreR.TabIndex = 27;
            this.btlettreR.Text = "R";
            this.btlettreR.UseVisualStyleBackColor = true;
            this.btlettreR.Click += new System.EventHandler(this.btlettreR_Click);
            // 
            // btlettreS
            // 
            this.btlettreS.Location = new System.Drawing.Point(195, 309);
            this.btlettreS.Name = "btlettreS";
            this.btlettreS.Size = new System.Drawing.Size(39, 38);
            this.btlettreS.TabIndex = 28;
            this.btlettreS.Text = "S";
            this.btlettreS.UseVisualStyleBackColor = true;
            this.btlettreS.Click += new System.EventHandler(this.btlettreS_Click);
            // 
            // btlettreT
            // 
            this.btlettreT.Location = new System.Drawing.Point(240, 309);
            this.btlettreT.Name = "btlettreT";
            this.btlettreT.Size = new System.Drawing.Size(39, 38);
            this.btlettreT.TabIndex = 29;
            this.btlettreT.Text = "T";
            this.btlettreT.UseVisualStyleBackColor = true;
            this.btlettreT.Click += new System.EventHandler(this.btlettreT_Click);
            // 
            // btlettreU
            // 
            this.btlettreU.Location = new System.Drawing.Point(285, 309);
            this.btlettreU.Name = "btlettreU";
            this.btlettreU.Size = new System.Drawing.Size(39, 38);
            this.btlettreU.TabIndex = 30;
            this.btlettreU.Text = "U";
            this.btlettreU.UseVisualStyleBackColor = true;
            this.btlettreU.Click += new System.EventHandler(this.btlettreU_Click);
            // 
            // btlettreV
            // 
            this.btlettreV.Location = new System.Drawing.Point(60, 353);
            this.btlettreV.Name = "btlettreV";
            this.btlettreV.Size = new System.Drawing.Size(39, 38);
            this.btlettreV.TabIndex = 31;
            this.btlettreV.Text = "V";
            this.btlettreV.UseVisualStyleBackColor = true;
            this.btlettreV.Click += new System.EventHandler(this.btlettreV_Click);
            // 
            // btlettreW
            // 
            this.btlettreW.Location = new System.Drawing.Point(105, 353);
            this.btlettreW.Name = "btlettreW";
            this.btlettreW.Size = new System.Drawing.Size(39, 38);
            this.btlettreW.TabIndex = 32;
            this.btlettreW.Text = "W";
            this.btlettreW.UseVisualStyleBackColor = true;
            this.btlettreW.Click += new System.EventHandler(this.btlettreW_Click);
            // 
            // btlettreX
            // 
            this.btlettreX.Location = new System.Drawing.Point(150, 353);
            this.btlettreX.Name = "btlettreX";
            this.btlettreX.Size = new System.Drawing.Size(39, 38);
            this.btlettreX.TabIndex = 33;
            this.btlettreX.Text = "X";
            this.btlettreX.UseVisualStyleBackColor = true;
            this.btlettreX.Click += new System.EventHandler(this.btlettreX_Click);
            // 
            // btlettreY
            // 
            this.btlettreY.Location = new System.Drawing.Point(195, 353);
            this.btlettreY.Name = "btlettreY";
            this.btlettreY.Size = new System.Drawing.Size(39, 38);
            this.btlettreY.TabIndex = 34;
            this.btlettreY.Text = "Y";
            this.btlettreY.UseVisualStyleBackColor = true;
            this.btlettreY.Click += new System.EventHandler(this.btlettreY_Click);
            // 
            // btlettreZ
            // 
            this.btlettreZ.Location = new System.Drawing.Point(237, 353);
            this.btlettreZ.Name = "btlettreZ";
            this.btlettreZ.Size = new System.Drawing.Size(39, 38);
            this.btlettreZ.TabIndex = 35;
            this.btlettreZ.Text = "Z";
            this.btlettreZ.UseVisualStyleBackColor = true;
            this.btlettreZ.Click += new System.EventHandler(this.btlettreZ_Click);
            // 
            // btCancel
            // 
            this.btCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.Location = new System.Drawing.Point(15, 433);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(84, 38);
            this.btCancel.TabIndex = 2;
            this.btCancel.Text = "CANCEL";
            this.btCancel.UseVisualStyleBackColor = true;
            this.btCancel.Click += new System.EventHandler(this.btCancel_Click);
            // 
            // btEnter
            // 
            this.btEnter.Enabled = false;
            this.btEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEnter.Location = new System.Drawing.Point(240, 433);
            this.btEnter.Name = "btEnter";
            this.btEnter.Size = new System.Drawing.Size(84, 38);
            this.btEnter.TabIndex = 36;
            this.btEnter.Text = "ENTER";
            this.btEnter.UseVisualStyleBackColor = true;
            this.btEnter.Click += new System.EventHandler(this.btEnter_Click);
            // 
            // btnum0
            // 
            this.btnum0.Location = new System.Drawing.Point(195, 146);
            this.btnum0.Name = "btnum0";
            this.btnum0.Size = new System.Drawing.Size(39, 38);
            this.btnum0.TabIndex = 2;
            this.btnum0.Text = "0";
            this.btnum0.UseVisualStyleBackColor = true;
            this.btnum0.Click += new System.EventHandler(this.btnum0_Click);
            // 
            // pbVoyant
            // 
            this.pbVoyant.InitialImage = null;
            this.pbVoyant.Location = new System.Drawing.Point(285, 40);
            this.pbVoyant.Name = "pbVoyant";
            this.pbVoyant.Size = new System.Drawing.Size(39, 39);
            this.pbVoyant.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbVoyant.TabIndex = 38;
            this.pbVoyant.TabStop = false;
            // 
            // tbMdp
            // 
            this.tbMdp.Enabled = false;
            this.tbMdp.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMdp.Location = new System.Drawing.Point(150, 40);
            this.tbMdp.MaxLength = 6;
            this.tbMdp.Name = "tbMdp";
            this.tbMdp.Size = new System.Drawing.Size(129, 39);
            this.tbMdp.TabIndex = 39;
            this.tbMdp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbMatricule
            // 
            this.lbMatricule.AutoSize = true;
            this.lbMatricule.Location = new System.Drawing.Point(48, 82);
            this.lbMatricule.Name = "lbMatricule";
            this.lbMatricule.Size = new System.Drawing.Size(65, 17);
            this.lbMatricule.TabIndex = 40;
            this.lbMatricule.Text = "Matricule";
            // 
            // lbMdp
            // 
            this.lbMdp.AutoSize = true;
            this.lbMdp.Location = new System.Drawing.Point(166, 82);
            this.lbMdp.Name = "lbMdp";
            this.lbMdp.Size = new System.Drawing.Size(93, 17);
            this.lbMdp.TabIndex = 43;
            this.lbMdp.Text = "Mot de passe";
            // 
            // gbDigicode
            // 
            this.gbDigicode.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbDigicode.Controls.Add(this.lbMdp);
            this.gbDigicode.Controls.Add(this.lbMatricule);
            this.gbDigicode.Controls.Add(this.tbMdp);
            this.gbDigicode.Controls.Add(this.pbVoyant);
            this.gbDigicode.Controls.Add(this.btnum0);
            this.gbDigicode.Controls.Add(this.btEnter);
            this.gbDigicode.Controls.Add(this.btCancel);
            this.gbDigicode.Controls.Add(this.btlettreZ);
            this.gbDigicode.Controls.Add(this.btlettreY);
            this.gbDigicode.Controls.Add(this.btlettreX);
            this.gbDigicode.Controls.Add(this.btlettreW);
            this.gbDigicode.Controls.Add(this.btlettreV);
            this.gbDigicode.Controls.Add(this.btlettreU);
            this.gbDigicode.Controls.Add(this.btlettreT);
            this.gbDigicode.Controls.Add(this.btlettreS);
            this.gbDigicode.Controls.Add(this.btlettreR);
            this.gbDigicode.Controls.Add(this.btlettreQ);
            this.gbDigicode.Controls.Add(this.btlettreP);
            this.gbDigicode.Controls.Add(this.btlettreO);
            this.gbDigicode.Controls.Add(this.btlettreN);
            this.gbDigicode.Controls.Add(this.btlettreM);
            this.gbDigicode.Controls.Add(this.btlettreL);
            this.gbDigicode.Controls.Add(this.btlettreK);
            this.gbDigicode.Controls.Add(this.btlettreJ);
            this.gbDigicode.Controls.Add(this.btlettreI);
            this.gbDigicode.Controls.Add(this.btlettreH);
            this.gbDigicode.Controls.Add(this.btlettreG);
            this.gbDigicode.Controls.Add(this.btlettreF);
            this.gbDigicode.Controls.Add(this.btlettreE);
            this.gbDigicode.Controls.Add(this.btlettreD);
            this.gbDigicode.Controls.Add(this.btlettreC);
            this.gbDigicode.Controls.Add(this.btlettreB);
            this.gbDigicode.Controls.Add(this.btlettreA);
            this.gbDigicode.Controls.Add(this.btnum9);
            this.gbDigicode.Controls.Add(this.btnum8);
            this.gbDigicode.Controls.Add(this.btnum7);
            this.gbDigicode.Controls.Add(this.btnum6);
            this.gbDigicode.Controls.Add(this.btnum5);
            this.gbDigicode.Controls.Add(this.btnum4);
            this.gbDigicode.Controls.Add(this.btnum3);
            this.gbDigicode.Controls.Add(this.btnum2);
            this.gbDigicode.Controls.Add(this.btnum1);
            this.gbDigicode.Controls.Add(this.tbMatricule);
            this.gbDigicode.Location = new System.Drawing.Point(12, 12);
            this.gbDigicode.Name = "gbDigicode";
            this.gbDigicode.Size = new System.Drawing.Size(340, 477);
            this.gbDigicode.TabIndex = 1;
            this.gbDigicode.TabStop = false;
            this.gbDigicode.Text = "Digicode M2L";
            // 
            // AccesSalleInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 502);
            this.Controls.Add(this.gbDigicode);
            this.Name = "AccesSalleInfo";
            this.Text = "Digicode salle informatique";
            this.Load += new System.EventHandler(this.AccesSalleInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbVoyant)).EndInit();
            this.gbDigicode.ResumeLayout(false);
            this.gbDigicode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList ListeVoyant;
        private System.Windows.Forms.TextBox tbMatricule;
        private System.Windows.Forms.Button btnum1;
        private System.Windows.Forms.Button btnum2;
        private System.Windows.Forms.Button btnum3;
        private System.Windows.Forms.Button btnum4;
        private System.Windows.Forms.Button btnum5;
        private System.Windows.Forms.Button btnum6;
        private System.Windows.Forms.Button btnum7;
        private System.Windows.Forms.Button btnum8;
        private System.Windows.Forms.Button btnum9;
        private System.Windows.Forms.Button btlettreA;
        private System.Windows.Forms.Button btlettreB;
        private System.Windows.Forms.Button btlettreC;
        private System.Windows.Forms.Button btlettreD;
        private System.Windows.Forms.Button btlettreE;
        private System.Windows.Forms.Button btlettreF;
        private System.Windows.Forms.Button btlettreG;
        private System.Windows.Forms.Button btlettreH;
        private System.Windows.Forms.Button btlettreI;
        private System.Windows.Forms.Button btlettreJ;
        private System.Windows.Forms.Button btlettreK;
        private System.Windows.Forms.Button btlettreL;
        private System.Windows.Forms.Button btlettreM;
        private System.Windows.Forms.Button btlettreN;
        private System.Windows.Forms.Button btlettreO;
        private System.Windows.Forms.Button btlettreP;
        private System.Windows.Forms.Button btlettreQ;
        private System.Windows.Forms.Button btlettreR;
        private System.Windows.Forms.Button btlettreS;
        private System.Windows.Forms.Button btlettreT;
        private System.Windows.Forms.Button btlettreU;
        private System.Windows.Forms.Button btlettreV;
        private System.Windows.Forms.Button btlettreW;
        private System.Windows.Forms.Button btlettreX;
        private System.Windows.Forms.Button btlettreY;
        private System.Windows.Forms.Button btlettreZ;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btEnter;
        private System.Windows.Forms.Button btnum0;
        private System.Windows.Forms.PictureBox pbVoyant;
        private System.Windows.Forms.TextBox tbMdp;
        private System.Windows.Forms.Label lbMatricule;
        private System.Windows.Forms.Label lbMdp;
        private System.Windows.Forms.GroupBox gbDigicode;
    }
}