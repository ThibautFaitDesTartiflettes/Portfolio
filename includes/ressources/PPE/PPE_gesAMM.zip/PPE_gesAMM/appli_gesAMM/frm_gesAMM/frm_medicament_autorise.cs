﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frm_medicament_autorise : Form
    {
        public frm_medicament_autorise()
        {
            InitializeComponent();
            bd.lireLesFamilles();
        }

        private void btRetour_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frm_medicament_autorise_Load(object sender, EventArgs e)
        {
            lvNbMedicAuto.Items.Clear();
            foreach ( string reference in Globale.lesFamilles.Keys)
            {
                Famille uneFamille = Globale.lesFamilles[reference];

                ListViewItem laLigne = new ListViewItem();
                laLigne.Text = uneFamille.getCode();
                laLigne.SubItems.Add(uneFamille.getLibelle());
                laLigne.SubItems.Add(uneFamille.getNbMediAmm().ToString());
                lvNbMedicAuto.Items.Add(laLigne);

            }
        }

        private void lvNbMedicAuto_MouseClick(object sender, MouseEventArgs e)
        { 
            if(lvNbMedicAuto.Items.Count > 0)
            {
                frmMedicamentAutorise frm = new frmMedicamentAutorise(lvNbMedicAuto.Items[lvNbMedicAuto.SelectedItems[0].Index].Text);
                frm.MdiParent = this.MdiParent;
                frm.Show();
            }
            
        }
    }
}
    