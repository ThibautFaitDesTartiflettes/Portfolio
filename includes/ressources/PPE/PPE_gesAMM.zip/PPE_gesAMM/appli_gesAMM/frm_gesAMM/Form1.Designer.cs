﻿namespace frm_gesAMM
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.consultationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médicamentEnCoursDeValidationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.etapeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saisirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modifierUneÉtapeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.medicamentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Consultation = new System.Windows.Forms.ToolStripMenuItem();
            this.workFlowDesÉtapesDunMédicamentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.médicamentsEnCoursDeValidationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Etape = new System.Windows.Forms.ToolStripMenuItem();
            this.saisieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modifierUneÉtapeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Enabled = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultationToolStripMenuItem,
            this.etapeToolStripMenuItem,
            this.medicamentToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1232, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // consultationToolStripMenuItem
            // 
            this.consultationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1,
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem,
            this.médicamentEnCoursDeValidationToolStripMenuItem});
            this.consultationToolStripMenuItem.Name = "consultationToolStripMenuItem";
            this.consultationToolStripMenuItem.Size = new System.Drawing.Size(104, 24);
            this.consultationToolStripMenuItem.Text = "Consultation";
            // 
            // workflowDesÉtapesDunMédicamentToolStripMenuItem1
            // 
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1.Name = "workflowDesÉtapesDunMédicamentToolStripMenuItem1";
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1.Size = new System.Drawing.Size(380, 26);
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1.Text = "Workflow des étapes d\'un médicament";
            this.workflowDesÉtapesDunMédicamentToolStripMenuItem1.Click += new System.EventHandler(this.workflowDesÉtapesDunMédicamentToolStripMenuItem1_Click);
            // 
            // nombreDeMédicamentAutoriséParFamilleToolStripMenuItem
            // 
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem.Name = "nombreDeMédicamentAutoriséParFamilleToolStripMenuItem";
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem.Size = new System.Drawing.Size(380, 26);
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem.Text = "Nombre de médicament autorisé par famille";
            this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem.Click += new System.EventHandler(this.nombreDeMédicamentAutoriséParFamilleToolStripMenuItem_Click);
            // 
            // médicamentEnCoursDeValidationToolStripMenuItem
            // 
            this.médicamentEnCoursDeValidationToolStripMenuItem.Name = "médicamentEnCoursDeValidationToolStripMenuItem";
            this.médicamentEnCoursDeValidationToolStripMenuItem.Size = new System.Drawing.Size(380, 26);
            this.médicamentEnCoursDeValidationToolStripMenuItem.Text = "Médicament en cours de validation";
            this.médicamentEnCoursDeValidationToolStripMenuItem.Click += new System.EventHandler(this.médicamentEnCoursDeValidationToolStripMenuItem_Click);
            // 
            // etapeToolStripMenuItem
            // 
            this.etapeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saisirToolStripMenuItem,
            this.modifierUneÉtapeToolStripMenuItem1});
            this.etapeToolStripMenuItem.Name = "etapeToolStripMenuItem";
            this.etapeToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.etapeToolStripMenuItem.Text = "Etape";
            // 
            // saisirToolStripMenuItem
            // 
            this.saisirToolStripMenuItem.Name = "saisirToolStripMenuItem";
            this.saisirToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.saisirToolStripMenuItem.Text = "Saisir une décision";
            this.saisirToolStripMenuItem.Click += new System.EventHandler(this.saisirToolStripMenuItem_Click);
            // 
            // modifierUneÉtapeToolStripMenuItem1
            // 
            this.modifierUneÉtapeToolStripMenuItem1.Name = "modifierUneÉtapeToolStripMenuItem1";
            this.modifierUneÉtapeToolStripMenuItem1.Size = new System.Drawing.Size(211, 26);
            this.modifierUneÉtapeToolStripMenuItem1.Text = "Modifier une étape";
            this.modifierUneÉtapeToolStripMenuItem1.Click += new System.EventHandler(this.modifierUneÉtapeToolStripMenuItem1_Click);
            // 
            // medicamentToolStripMenuItem
            // 
            this.medicamentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajouterToolStripMenuItem});
            this.medicamentToolStripMenuItem.Name = "medicamentToolStripMenuItem";
            this.medicamentToolStripMenuItem.Size = new System.Drawing.Size(104, 24);
            this.medicamentToolStripMenuItem.Text = "Medicament";
            // 
            // ajouterToolStripMenuItem
            // 
            this.ajouterToolStripMenuItem.Name = "ajouterToolStripMenuItem";
            this.ajouterToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.ajouterToolStripMenuItem.Text = "Ajouter";
            this.ajouterToolStripMenuItem.Click += new System.EventHandler(this.ajouterToolStripMenuItem_Click);
            // 
            // Consultation
            // 
            this.Consultation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.workFlowDesÉtapesDunMédicamentToolStripMenuItem,
            this.nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem,
            this.médicamentsEnCoursDeValidationToolStripMenuItem});
            this.Consultation.Enabled = false;
            this.Consultation.Name = "Consultation";
            this.Consultation.Size = new System.Drawing.Size(104, 24);
            this.Consultation.Text = "Consultation";
            // 
            // workFlowDesÉtapesDunMédicamentToolStripMenuItem
            // 
            this.workFlowDesÉtapesDunMédicamentToolStripMenuItem.Name = "workFlowDesÉtapesDunMédicamentToolStripMenuItem";
            this.workFlowDesÉtapesDunMédicamentToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.workFlowDesÉtapesDunMédicamentToolStripMenuItem.Text = "WorkFlow des étapes d\'un médicament";
            // 
            // nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem
            // 
            this.nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem.Name = "nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem";
            this.nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem.Text = "Nombre de médicaments autorisés par famille";
            // 
            // médicamentsEnCoursDeValidationToolStripMenuItem
            // 
            this.médicamentsEnCoursDeValidationToolStripMenuItem.Name = "médicamentsEnCoursDeValidationToolStripMenuItem";
            this.médicamentsEnCoursDeValidationToolStripMenuItem.Size = new System.Drawing.Size(392, 26);
            this.médicamentsEnCoursDeValidationToolStripMenuItem.Text = "Médicaments en cours de validation";
            // 
            // Etape
            // 
            this.Etape.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saisieToolStripMenuItem,
            this.modifierUneÉtapeToolStripMenuItem});
            this.Etape.Enabled = false;
            this.Etape.Name = "Etape";
            this.Etape.Size = new System.Drawing.Size(59, 24);
            this.Etape.Text = "Etape";
            // 
            // saisieToolStripMenuItem
            // 
            this.saisieToolStripMenuItem.Name = "saisieToolStripMenuItem";
            this.saisieToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.saisieToolStripMenuItem.Text = "Saisie de décision";
            // 
            // modifierUneÉtapeToolStripMenuItem
            // 
            this.modifierUneÉtapeToolStripMenuItem.Name = "modifierUneÉtapeToolStripMenuItem";
            this.modifierUneÉtapeToolStripMenuItem.Size = new System.Drawing.Size(211, 26);
            this.modifierUneÉtapeToolStripMenuItem.Text = "Modifier une étape";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1232, 853);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "gesAMM";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Consultation;
        private System.Windows.Forms.ToolStripMenuItem workFlowDesÉtapesDunMédicamentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nombreDeMédicamentsAutorisésParFamilleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médicamentsEnCoursDeValidationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Etape;
        private System.Windows.Forms.ToolStripMenuItem saisieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modifierUneÉtapeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medicamentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem etapeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem workflowDesÉtapesDunMédicamentToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nombreDeMédicamentAutoriséParFamilleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem médicamentEnCoursDeValidationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modifierUneÉtapeToolStripMenuItem1;
    }
}

