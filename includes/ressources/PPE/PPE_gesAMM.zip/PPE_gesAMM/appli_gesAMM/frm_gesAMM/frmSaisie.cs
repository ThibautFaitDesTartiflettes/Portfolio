﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frmSaisie : Form
    {
        public DataTable maTable;
        private bool Chargé = false;

        public frmSaisie()
        {
            InitializeComponent();
        }

        private void frmSaisie_Load(object sender, EventArgs e)
        {
            update();
        }

        public void update()
        {
            Chargé = false;
            gpAMM.Enabled = false;
            btAjouter.Enabled = false;
            maTable = new DataTable();
            maTable.Columns.Add("depotLegal");          // clé
            maTable.Columns.Add("NomCommercial");

            gpEtapeDer.Enabled = false;
            foreach (string keys in Globale.lesMedicaments.Keys)
            {

                if (Globale.lesMedicaments[keys].getDerniereEtape() >= 0 && Globale.lesMedicaments[keys].getDerniereEtape() < 8 && (Globale.lesMedicaments[keys].GetDernierWorkFlowValide() || Globale.lesMedicaments[keys].getLesWorkflows().Count == 0))
                {
                    maTable.Rows.Add(keys, Globale.lesMedicaments[keys].getNomCommercial());
                }

            }



            cbMedicament.DataSource = maTable;
            cbMedicament.DisplayMember = "NomCommercial";
            cbMedicament.ValueMember = "depotLegal";
            Chargé = true;
        }

        public void updateText()
        {
            if (Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows().Count == 0)
            {
                tbDateDer.Text = "NULL";
                tbLibelDer.Text = "NULL";
                tbNormeDer.Text = "NULL";
                tbNumDer.Text = "NULL";


            }
            else
            {

                int j = Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows().Count - 1;
                Etape unetape = Globale.lesEtapes[Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getDerniereEtape() - 1];
                tbDateDer.Text = Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows()[j].getDateDecision().ToShortDateString();
                tbLibelDer.Text = unetape.getLibelle();
                tbNumDer.Text = unetape.getNum().ToString();

                if (unetape.GetType().Name == "EtapeNormee")
                {
                    tbNormeDer.Text = (unetape as EtapeNormee).getNorme();
                }
                else
                {
                    tbNormeDer.Text = "";
                }

            }
        }

        public void CheckButton()
        {
            bool accepter = true;
            if ( !rbAccepter.Checked && !rbRefuser.Checked)
            {
                accepter = false;
            }

            if (dpAjouter.Value.ToString() == "")
            {
                accepter = false;
            }

            if (tbAjouterNuméro.Text == "8" && tbAMM.Text == "")
            {
                accepter = false;
            }

          

            btAjouter.Enabled = accepter;

        }

        private void cbMedicament_SelectedIndexChanged(object sender, EventArgs e)
        {

          
            if (gpEtapeDer.Text == "")
            {

                gpEtapeDer.Enabled = false;

            }
            else
            {

             

                if (Chargé)
                {
                    gpEtapeDer.Enabled = true;
                    gpAjouterEtape.Enabled = true;

                    if (Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows().Count == 0)
                    {
                        tbDateDer.Text = "NULL";
                        tbLibelDer.Text = "NULL";
                        tbNormeDer.Text = "NULL";
                        tbNumDer.Text = "NULL";


                    }
                    else
                    {
                       
                        int j = Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows().Count - 1;
                        Etape unetape = Globale.lesEtapes[Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getDerniereEtape() - 1];
                        tbDateDer.Text = Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows()[j].getDateDecision().ToShortDateString();
                        tbLibelDer.Text = unetape.getLibelle();
                        tbNumDer.Text = unetape.getNum().ToString();

                        if (unetape.GetType().Name == "EtapeNormee")
                        {
                            tbNormeDer.Text = (unetape as EtapeNormee).getNorme();
                        }
                        else
                        {
                            tbNormeDer.Text = "";
                        }

                    }

                    int i = Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getLesWorkflows().Count;
                    Etape etape = Globale.lesEtapes[Globale.lesMedicaments[cbMedicament.SelectedValue.ToString()].getDerniereEtape()];


                    Console.WriteLine();
                    tbAjouterLibelle.Text = etape.getLibelle();
                    tbAjouterNuméro.Text = etape.getNum().ToString();


                    if (etape.GetType().Name == "EtapeNormee")
                    {
                        tbAjouterNorme.Text = (etape as EtapeNormee).getNorme();
                    }
                    else
                    {
                        tbAjouterNorme.Text = "";
                    }

                    Console.WriteLine(i);

                    if (etape.getNum() >= 8)
                    {
                        gpAMM.Enabled = true;
                       
                    }
                    else
                    {
                        gpAMM.Enabled = false;
                    }


                }

                
            }
         
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

            CheckButton();

        }

        private void gpEtapeDer_Enter(object sender, EventArgs e)
        {

        }

        private void rbAccepter_CheckedChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void dpAjouter_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void btAjouter_Click(object sender, EventArgs e)
        {
            if (rbRefuser.Checked)
            {
                bd.insertWorkflows(cbMedicament.SelectedValue.ToString(), int.Parse(tbAjouterNuméro.Text), 1, dpAjouter.Value) ;
            }
            else
            {
                bd.insertWorkflows(cbMedicament.SelectedValue.ToString(), int.Parse(tbAjouterNuméro.Text),0,dpAjouter.Value);
            }

            if (tbAjouterNuméro.Text == "8")
            {
                bd.updateAMM(tbAMM.Text,cbMedicament.SelectedValue.ToString());
            }


            bd.lireLesMedicaments();


            update();

          

            tbDateDer.Text = "";
            tbLibelDer.Text = "";
            tbNormeDer.Text = "";
            tbNumDer.Text = "";
            tbAjouterLibelle.Text = "";
            tbAjouterNuméro.Text = "";
            tbAjouterNorme.Text = "";
            rbAccepter.Checked = false;
            rbRefuser.Checked = false;

            CheckButton();

        }

        private void tbAMM_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }
    }
}
