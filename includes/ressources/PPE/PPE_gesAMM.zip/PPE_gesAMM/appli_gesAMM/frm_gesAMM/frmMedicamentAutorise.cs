﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frmMedicamentAutorise : Form
    {
        string codeFamille;
        public frmMedicamentAutorise(string leCodeFamille)
        {
            InitializeComponent();
            this.codeFamille = leCodeFamille;
        }

        public void update()
        {
            lvMedicamentAuto.Items.Clear();
            

            foreach (string reference in Globale.lesMedicaments.Keys)
            {
                Medicament unMedicament = Globale.lesMedicaments[reference];
                if (unMedicament.getDerniereEtape() >= 8 && unMedicament.getCodeFamille() == this.codeFamille)
                {
                    ListViewItem laligne = new ListViewItem();
                    laligne.Text = unMedicament.getDepotLegal();
                    laligne.SubItems.Add(unMedicament.getNomCommercial());
                    laligne.SubItems.Add(unMedicament.getAmm());
                    lvMedicamentAuto.Items.Add(laligne);
                }
            }
            
            
        }

        private void frmMedicamentAutorise_Load(object sender, EventArgs e)
        {
            update();
        }
    }
}
