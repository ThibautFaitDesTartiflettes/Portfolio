﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class EtapeNormee : Etape
    {
        private string norme;
        private DateTime dateNorme;

        public EtapeNormee(int leNum, string leLibelle, string laNorme, DateTime laDateNorme)
            : base (leNum, leLibelle)
        {
            this.norme = laNorme;
            this.dateNorme = laDateNorme;
        }

        public string getNorme() { return this.norme; }
        public DateTime getDateNorme() { return this.dateNorme; }

        public void setNorme(string laNorme) { this.norme = laNorme; }
        public void setDateNorme(DateTime laDateNorme) { this.dateNorme = laDateNorme; }
    }
}
