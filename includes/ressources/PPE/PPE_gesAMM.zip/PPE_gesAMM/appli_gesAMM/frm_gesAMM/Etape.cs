﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class Etape
    {
        private int num;
        private string libelle;


        //dqssq
        public Etape(int leNum, string leLibelle)
        {
            this.num = leNum;
            this.libelle = leLibelle;
        }

        public int getNum() { return this.num; }
        public string getLibelle() { return this.libelle; }

        public void setNum(int leNum) { this.num = leNum; }
        public void setLibelle(string leLibelle) { this.libelle = leLibelle; }

    }
}
