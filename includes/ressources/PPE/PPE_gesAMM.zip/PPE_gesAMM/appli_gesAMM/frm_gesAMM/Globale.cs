﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class Globale
    {
        public static Dictionary<string, Famille> lesFamilles;
        public static Dictionary<string, Medicament> lesMedicaments;
        public static List<Etape> lesEtapes;
        public static List<Decision> lesDecisions;
        public static SqlConnection cnx;
        public static int numUtilConnecté;

        public static void LoadConnexion(string HoteName,string dateBaseName)
        {
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source="+HoteName+";Initial Catalog="+ dateBaseName+ ";Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();
            
        }

    }




}
