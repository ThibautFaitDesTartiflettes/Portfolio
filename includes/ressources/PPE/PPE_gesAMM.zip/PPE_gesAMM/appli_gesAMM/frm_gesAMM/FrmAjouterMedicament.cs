﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class FrmAjouterMedicament : Form
    {
        public DataTable maTable;


        public void CheckButton()
        {
            bool enable = true;

            if (tbDepot.Text  == "")
            {
                enable = false;
            }

            if (cbFamille.Text == "")
            {
                enable = false;
            }

            if (rtbComposition.Text == "")
            {
                enable = false;
            }

            if (rtbEffets.Text == "")
            {
                enable = false;
            }


            if (rtbIndication.Text == "")
            {
                enable = false;
            }


            btAjouter.Enabled = enable;
        }

        public FrmAjouterMedicament()
        {
            InitializeComponent();
            maTable = new DataTable();
            maTable.Columns.Add("libelle");
            maTable.Columns.Add("code");
        }

        private void AjouterMedicament_Load(object sender, EventArgs e)
        {
            foreach (string key in Globale.lesFamilles.Keys)
            {
   
                maTable.Rows.Add(key + " " + Globale.lesFamilles[key].getLibelle(),key);

            }

            cbFamille.DataSource = maTable;
            cbFamille.DisplayMember = "libelle";
            cbFamille.ValueMember = "code";
        }

        private void tbDepot_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void tbNomCommercial_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void rtbComposition_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void rtbEffets_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void rtbIndication_TextChanged(object sender, EventArgs e)
        {
            CheckButton();
        }

        private void btAjouter_Click(object sender, EventArgs e)
        {

            if (Globale.lesMedicaments.ContainsKey(tbDepot.Text))
            {
                MessageBox.Show("Ce dépot légale est déjà attribué à un autre medicament", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
              

                bd.ajouterMedicament(tbDepot.Text, tbNomCommercial.Text, rtbComposition.Text, rtbEffets.Text, rtbComposition.Text, cbFamille.SelectedValue.ToString());
                MessageBox.Show("Le medicament à bien été ajouté", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                rtbComposition.Text = "";
                rtbEffets.Text = "";
                tbDepot.Text = "";
                tbNomCommercial.Text = "";
                rtbIndication.Text = "";
                rtbEffets.Text = "";
                btAjouter.Enabled = false;
                bd.lireLesMedicaments();
            }
        }
    }
}
