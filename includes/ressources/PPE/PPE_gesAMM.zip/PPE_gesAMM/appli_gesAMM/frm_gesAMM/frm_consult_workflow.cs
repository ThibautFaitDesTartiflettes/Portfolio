﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frm_consult_workflow : Form
    {
        public DataTable maTable;
        public bool charge = false;
        public frm_consult_workflow()
        {
            InitializeComponent();
        }

        public frm_consult_workflow(string depotLegal)
        {
            
            InitializeComponent();
            update(depotLegal);
            cbMedicament.Text = depotLegal;


        }

        private void frm_consult_workflow_Load(object sender, EventArgs e)
        {

            maTable = new DataTable();
            maTable.Columns.Add("depotLegal");
            maTable.Columns.Add("NomCommercial");

            foreach (string reference in Globale.lesMedicaments.Keys)
            {
                Medicament unMedicament = Globale.lesMedicaments[reference];

                maTable.Rows.Add(reference, Globale.lesMedicaments[reference].getNomCommercial());
            }

            cbMedicament.DataSource = maTable;
            cbMedicament.DisplayMember = "NomCommercial";
            cbMedicament.ValueMember = "depotLegal";

            charge = true;
        }

        public void update(string depot)
        {
            lvEtapes.Items.Clear();

            foreach (Workflow unWorkflow in Globale.lesMedicaments[depot].getLesWorkflows())
            {

                ListViewItem laLigne = new ListViewItem();
                laLigne.Text = unWorkflow.getNumEtape().ToString();
                laLigne.SubItems.Add(Globale.lesEtapes[unWorkflow.getNumEtape() - 1].getLibelle());
                laLigne.SubItems.Add(unWorkflow.getDateDecision().ToString());
                laLigne.SubItems.Add(Globale.lesDecisions[unWorkflow.getIdDecision()].getLibelle());

                Etape uneEtape = Globale.lesEtapes[unWorkflow.getNumEtape() - 1];
                if (uneEtape.GetType().Name == "EtapeNormee")
                {
                    laLigne.SubItems.Add((uneEtape as EtapeNormee).getNorme());
                    laLigne.SubItems.Add((uneEtape as EtapeNormee).getDateNorme().Date.ToString());
                }
                lvEtapes.Items.Add(laLigne);
            }

        }

        private void cbMedicament_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (charge)
            {
                update(cbMedicament.SelectedValue.ToString());
            }

           
        }

        private void btRetour_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
    }
}
