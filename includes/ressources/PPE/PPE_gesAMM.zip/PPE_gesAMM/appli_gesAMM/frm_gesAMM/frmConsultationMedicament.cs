﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frmConsultationMedicament : Form
    {
        frm_consult_workflow lesWorkFlows;
        bool display = false;

        public frmConsultationMedicament()
        {
            InitializeComponent();
        }

        private void frmConsultationMedicament_Load(object sender, EventArgs e)
        {
            lvMedicaments.Items.Clear();
            foreach (string key in Globale.lesMedicaments.Keys)
            {
                if (Globale.lesMedicaments[key].EstEnCours())
                {

                    ListViewItem ligne = new ListViewItem();

                    ligne.Text = key;
                    ligne.SubItems.Add(Globale.lesMedicaments[key].getNomCommercial() );
                    ligne.SubItems.Add(Globale.lesMedicaments[key].getCodeFamille());


                    lvMedicaments.Items.Add(ligne);

                }



            }
        }

        private void lvMedicaments_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void lvMedicaments_SelectedIndexChanged(object sender, MouseEventArgs e)
        {
            if (lvMedicaments.SelectedItems.Count > 0 && display == false)
            {
                Console.WriteLine(lvMedicaments.Items[lvMedicaments.SelectedItems[0].Index].Text);
                lesWorkFlows = new frm_consult_workflow(lvMedicaments.Items[lvMedicaments.SelectedItems[0].Index].Text);
                lesWorkFlows.MdiParent = this.MdiParent;
                lesWorkFlows.Show();
                display = true;
            }
            display = false;
        }
    }
}
