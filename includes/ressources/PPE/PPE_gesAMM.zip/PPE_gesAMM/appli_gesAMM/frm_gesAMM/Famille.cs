﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class Famille
    {
        private string code;
        private string libelle;
        private int nbMediAmm;

        public Famille(string leCode, string leLibelle, int leNbMediAmm)
        {
            this.code = leCode;
            this.libelle = leLibelle;
            this.nbMediAmm = leNbMediAmm;
        }

        public string getCode() { return this.code; }
        public string getLibelle() { return this.libelle; }
        public int getNbMediAmm() { return this.nbMediAmm; }

        public void setCode(string leCode) { this.code = leCode; }
        public void setLibelle(string leLibelle) { this.libelle = leLibelle;}
        public void setNbMediAmm(int leNbMediAmm) { this.nbMediAmm = leNbMediAmm; }
    }
}
