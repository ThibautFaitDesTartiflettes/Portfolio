﻿namespace frm_gesAMM
{
    partial class frmSaisie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbMedicament = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gpEtapeDer = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbDateDer = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNormeDer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbLibelDer = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNumDer = new System.Windows.Forms.TextBox();
            this.gpAjouterEtape = new System.Windows.Forms.GroupBox();
            this.gpAMM = new System.Windows.Forms.GroupBox();
            this.tbAMM = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tbAjouterNuméro = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbRefuser = new System.Windows.Forms.RadioButton();
            this.rbAccepter = new System.Windows.Forms.RadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.dpAjouter = new System.Windows.Forms.DateTimePicker();
            this.btAjouter = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tbAjouterNorme = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbAjouterLibelle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.gpEtapeDer.SuspendLayout();
            this.gpAjouterEtape.SuspendLayout();
            this.gpAMM.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbMedicament
            // 
            this.cbMedicament.FormattingEnabled = true;
            this.cbMedicament.Location = new System.Drawing.Point(15, 81);
            this.cbMedicament.Name = "cbMedicament";
            this.cbMedicament.Size = new System.Drawing.Size(158, 24);
            this.cbMedicament.TabIndex = 0;
            this.cbMedicament.SelectedIndexChanged += new System.EventHandler(this.cbMedicament_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Les medicaments :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(90, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(331, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Saisie de décision de médicament";
            // 
            // gpEtapeDer
            // 
            this.gpEtapeDer.Controls.Add(this.label6);
            this.gpEtapeDer.Controls.Add(this.tbDateDer);
            this.gpEtapeDer.Controls.Add(this.label5);
            this.gpEtapeDer.Controls.Add(this.tbNormeDer);
            this.gpEtapeDer.Controls.Add(this.label4);
            this.gpEtapeDer.Controls.Add(this.tbLibelDer);
            this.gpEtapeDer.Controls.Add(this.label3);
            this.gpEtapeDer.Controls.Add(this.tbNumDer);
            this.gpEtapeDer.Enabled = false;
            this.gpEtapeDer.Location = new System.Drawing.Point(15, 111);
            this.gpEtapeDer.Name = "gpEtapeDer";
            this.gpEtapeDer.Size = new System.Drawing.Size(466, 121);
            this.gpEtapeDer.TabIndex = 3;
            this.gpEtapeDer.TabStop = false;
            this.gpEtapeDer.Text = "Dernière étape";
            this.gpEtapeDer.Enter += new System.EventHandler(this.gpEtapeDer_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(203, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = " Date  :";
            // 
            // tbDateDer
            // 
            this.tbDateDer.Location = new System.Drawing.Point(269, 71);
            this.tbDateDer.Name = "tbDateDer";
            this.tbDateDer.ReadOnly = true;
            this.tbDateDer.Size = new System.Drawing.Size(191, 22);
            this.tbDateDer.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Norme :";
            // 
            // tbNormeDer
            // 
            this.tbNormeDer.Location = new System.Drawing.Point(79, 70);
            this.tbNormeDer.Name = "tbNormeDer";
            this.tbNormeDer.ReadOnly = true;
            this.tbNormeDer.Size = new System.Drawing.Size(122, 22);
            this.tbNormeDer.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(210, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Libelle :";
            // 
            // tbLibelDer
            // 
            this.tbLibelDer.Location = new System.Drawing.Point(268, 37);
            this.tbLibelDer.Name = "tbLibelDer";
            this.tbLibelDer.ReadOnly = true;
            this.tbLibelDer.Size = new System.Drawing.Size(192, 22);
            this.tbLibelDer.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Numéro :";
            // 
            // tbNumDer
            // 
            this.tbNumDer.Location = new System.Drawing.Point(79, 36);
            this.tbNumDer.Name = "tbNumDer";
            this.tbNumDer.ReadOnly = true;
            this.tbNumDer.Size = new System.Drawing.Size(122, 22);
            this.tbNumDer.TabIndex = 0;
            // 
            // gpAjouterEtape
            // 
            this.gpAjouterEtape.Controls.Add(this.gpAMM);
            this.gpAjouterEtape.Controls.Add(this.tbAjouterNuméro);
            this.gpAjouterEtape.Controls.Add(this.groupBox1);
            this.gpAjouterEtape.Controls.Add(this.label10);
            this.gpAjouterEtape.Controls.Add(this.dpAjouter);
            this.gpAjouterEtape.Controls.Add(this.btAjouter);
            this.gpAjouterEtape.Controls.Add(this.label9);
            this.gpAjouterEtape.Controls.Add(this.tbAjouterNorme);
            this.gpAjouterEtape.Controls.Add(this.label8);
            this.gpAjouterEtape.Controls.Add(this.tbAjouterLibelle);
            this.gpAjouterEtape.Controls.Add(this.label7);
            this.gpAjouterEtape.Enabled = false;
            this.gpAjouterEtape.Location = new System.Drawing.Point(15, 238);
            this.gpAjouterEtape.Name = "gpAjouterEtape";
            this.gpAjouterEtape.Size = new System.Drawing.Size(466, 355);
            this.gpAjouterEtape.TabIndex = 4;
            this.gpAjouterEtape.TabStop = false;
            this.gpAjouterEtape.Text = "Ajouter une étape";
            // 
            // gpAMM
            // 
            this.gpAMM.Controls.Add(this.tbAMM);
            this.gpAMM.Controls.Add(this.label11);
            this.gpAMM.Enabled = false;
            this.gpAMM.Location = new System.Drawing.Point(0, 206);
            this.gpAMM.Name = "gpAMM";
            this.gpAMM.Size = new System.Drawing.Size(466, 74);
            this.gpAMM.TabIndex = 13;
            this.gpAMM.TabStop = false;
            this.gpAMM.Text = "Numéro d\'autorisation de mise sur la marché";
            // 
            // tbAMM
            // 
            this.tbAMM.Location = new System.Drawing.Point(79, 35);
            this.tbAMM.Name = "tbAMM";
            this.tbAMM.Size = new System.Drawing.Size(220, 22);
            this.tbAMM.TabIndex = 14;
            this.tbAMM.TextChanged += new System.EventHandler(this.tbAMM_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 17);
            this.label11.TabIndex = 10;
            this.label11.Text = "Numéro :";
            // 
            // tbAjouterNuméro
            // 
            this.tbAjouterNuméro.Location = new System.Drawing.Point(78, 27);
            this.tbAjouterNuméro.Name = "tbAjouterNuméro";
            this.tbAjouterNuméro.ReadOnly = true;
            this.tbAjouterNuméro.Size = new System.Drawing.Size(123, 22);
            this.tbAjouterNuméro.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbRefuser);
            this.groupBox1.Controls.Add(this.rbAccepter);
            this.groupBox1.Location = new System.Drawing.Point(0, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(466, 74);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Decision";
            // 
            // rbRefuser
            // 
            this.rbRefuser.AutoSize = true;
            this.rbRefuser.Location = new System.Drawing.Point(109, 31);
            this.rbRefuser.Name = "rbRefuser";
            this.rbRefuser.Size = new System.Drawing.Size(79, 21);
            this.rbRefuser.TabIndex = 0;
            this.rbRefuser.TabStop = true;
            this.rbRefuser.Text = "Refuser";
            this.rbRefuser.UseVisualStyleBackColor = true;
            this.rbRefuser.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rbAccepter
            // 
            this.rbAccepter.AutoSize = true;
            this.rbAccepter.Location = new System.Drawing.Point(294, 31);
            this.rbAccepter.Name = "rbAccepter";
            this.rbAccepter.Size = new System.Drawing.Size(85, 21);
            this.rbAccepter.TabIndex = 1;
            this.rbAccepter.TabStop = true;
            this.rbAccepter.Text = "Accepter";
            this.rbAccepter.UseVisualStyleBackColor = true;
            this.rbAccepter.CheckedChanged += new System.EventHandler(this.rbAccepter_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = " Date  :";
            // 
            // dpAjouter
            // 
            this.dpAjouter.Location = new System.Drawing.Point(78, 101);
            this.dpAjouter.Name = "dpAjouter";
            this.dpAjouter.Size = new System.Drawing.Size(143, 22);
            this.dpAjouter.TabIndex = 11;
            this.dpAjouter.ValueChanged += new System.EventHandler(this.dpAjouter_ValueChanged);
            // 
            // btAjouter
            // 
            this.btAjouter.Location = new System.Drawing.Point(176, 297);
            this.btAjouter.Name = "btAjouter";
            this.btAjouter.Size = new System.Drawing.Size(136, 32);
            this.btAjouter.TabIndex = 10;
            this.btAjouter.Text = "Ajouter";
            this.btAjouter.UseVisualStyleBackColor = true;
            this.btAjouter.Click += new System.EventHandler(this.btAjouter_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 66);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 17);
            this.label9.TabIndex = 9;
            this.label9.Text = "Norme :";
            // 
            // tbAjouterNorme
            // 
            this.tbAjouterNorme.Location = new System.Drawing.Point(78, 64);
            this.tbAjouterNorme.Name = "tbAjouterNorme";
            this.tbAjouterNorme.ReadOnly = true;
            this.tbAjouterNorme.Size = new System.Drawing.Size(122, 22);
            this.tbAjouterNorme.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(215, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "Libelle :";
            // 
            // tbAjouterLibelle
            // 
            this.tbAjouterLibelle.Location = new System.Drawing.Point(272, 26);
            this.tbAjouterLibelle.Name = "tbAjouterLibelle";
            this.tbAjouterLibelle.ReadOnly = true;
            this.tbAjouterLibelle.Size = new System.Drawing.Size(188, 22);
            this.tbAjouterLibelle.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "Numéro :";
            // 
            // frmSaisie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(493, 605);
            this.Controls.Add(this.gpAjouterEtape);
            this.Controls.Add(this.gpEtapeDer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMedicament);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmSaisie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Décision d\'une étape";
            this.Load += new System.EventHandler(this.frmSaisie_Load);
            this.gpEtapeDer.ResumeLayout(false);
            this.gpEtapeDer.PerformLayout();
            this.gpAjouterEtape.ResumeLayout(false);
            this.gpAjouterEtape.PerformLayout();
            this.gpAMM.ResumeLayout(false);
            this.gpAMM.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbMedicament;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gpEtapeDer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNumDer;
        private System.Windows.Forms.GroupBox gpAjouterEtape;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbDateDer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNormeDer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbLibelDer;
        private System.Windows.Forms.RadioButton rbRefuser;
        private System.Windows.Forms.RadioButton rbAccepter;
        private System.Windows.Forms.Button btAjouter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbAjouterNorme;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbAjouterLibelle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dpAjouter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbAjouterNuméro;
        private System.Windows.Forms.GroupBox gpAMM;
        private System.Windows.Forms.TextBox tbAMM;
        private System.Windows.Forms.Label label11;
    }
}