﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace frm_gesAMM
{
    static class  bd
    {
        public static void VerifierConnexion(string login, string mdp)
        {
            SqlCommand maRequete = new SqlCommand("prc_verifier_connexion", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter paramLoginUtil = new SqlParameter("@loginUtil", System.Data.SqlDbType.NVarChar, 25);
            paramLoginUtil.Value = login;
            maRequete.Parameters.Add(paramLoginUtil);

            SqlParameter paramMdpUtil = new SqlParameter("@mdpUtil", System.Data.SqlDbType.NVarChar, 50);
            paramMdpUtil.Value = mdp;
            maRequete.Parameters.Add(paramMdpUtil);

            SqlDataReader SqlExec = maRequete.ExecuteReader();

            while (SqlExec.Read())
            {
                int numUtil = int.Parse(SqlExec["UTL_NUM"].ToString());

                Globale.numUtilConnecté = numUtil;
            }
        }

        public static void lireLesMedicaments()
        {
            Globale.lesMedicaments.Clear();

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_SelectMedicament", Globale.cnx);

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                string leDepotLegal = SqlExec["MED_DEPOTLEGAL"].ToString();
                string nomCommercial = SqlExec["MED_NOMCOMMERCIAL"].ToString();
                string composition = SqlExec["MED_COMPOSITION"].ToString();
                string effects = SqlExec["MED_EFFETS"].ToString();
                string contreindic = SqlExec["MED_CONTREINDIC"].ToString();
                string medAMM = SqlExec["MED_AMM"].ToString();
                string famCodeMed = SqlExec["FAM_CODE_MED"].ToString();
                string etpnummed = SqlExec["ETP_NUM_MED"].ToString();
                int etpnummedint = 0;

                if (etpnummed == "")
                {
                     etpnummedint = 0;
                }
                else
                {
           
                    etpnummedint = int.Parse(etpnummed);
                }

                Medicament leMedoc = new Medicament(leDepotLegal,nomCommercial,composition,effects,contreindic,medAMM, etpnummedint, famCodeMed);

                


                Globale.lesMedicaments.Add(leDepotLegal,leMedoc);

             
            }


            foreach (string depotLegal in Globale.lesMedicaments.Keys)
            {
                SqlCommand maRequete2 = new SqlCommand("prc_SelectWorkFlowMedics", Globale.cnx);
                maRequete2.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter paramDepotLegal = new SqlParameter("@depotLegal", System.Data.SqlDbType.NVarChar, 10);
                paramDepotLegal.Value = depotLegal;

                maRequete2.Parameters.Add(paramDepotLegal);

                SqlDataReader SqlExec2 = maRequete2.ExecuteReader();

                while (SqlExec2.Read())
                {

                    DateTime laDateDecisition = DateTime.Parse(SqlExec2["dateDecision"].ToString());
                    int NumEtape = int.Parse(SqlExec2["ETP_NUM_SUB"].ToString());
                    int Decision = int.Parse(SqlExec2["DSC_ID_SUB"].ToString());


             
                    Workflow workflow = new Workflow(laDateDecisition, NumEtape, Decision);
                   
                    Globale.lesMedicaments[depotLegal].getLesWorkflows().Add(workflow);
                }
            }

            
        


        }

        public static void lireLesEtapes()
        {
            Globale.lesEtapes.Clear();

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_SelectEtapes", Globale.cnx);

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                string numEtape = SqlExec["ETP_NUM"].ToString();
                string libelleEtape = SqlExec["ETP_LIBELLE"].ToString();
                string normeEtape = SqlExec["ETP_NORME"].ToString();
                string dateNormeEtape = SqlExec["ETP_DATE_NORME"].ToString();

                Etape uneEtape;

                if (normeEtape != "" && dateNormeEtape != null)
                {
                    uneEtape = new EtapeNormee(int.Parse(numEtape), libelleEtape, normeEtape,DateTime.Parse(dateNormeEtape));
                  
                }
                else
                {
                    uneEtape = new Etape(int.Parse(numEtape), libelleEtape);
                }
                

                Globale.lesEtapes.Add(uneEtape);
            }

        }

        public static void lireLesFamilles()
        {
            Globale.lesFamilles.Clear();

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_selectFamilles", Globale.cnx);

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                string famCode = SqlExec["FAM_CODE"].ToString();
                string Famlibelle = SqlExec["FAM_LIBELLE"].ToString();
                string nombreFamille = SqlExec["FAM_NB_MEDI_AMM"].ToString();


                Famille laFamille = new Famille(famCode, Famlibelle, int.Parse(nombreFamille));

                Globale.lesFamilles.Add(famCode, laFamille);

            }
        }

        public static void lireLesDecisions()
        {
            Globale.lesDecisions.Clear();

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_SelectDecisions", Globale.cnx);

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                string dcsId = SqlExec["DCS_ID"].ToString();
                string dcsLibelle = SqlExec["DCS_LIBELLE"].ToString();


                Decision laDecision = new Decision(int.Parse(dcsId), dcsLibelle);

                Globale.lesDecisions.Add(laDecision);

            }
        }
        public static void updateNormeEtape(int num, string norme, DateTime date)
        {
            SqlCommand maRequete = new SqlCommand("prc_modifier_norme", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter paramNvNorme = new SqlParameter("@nvNorme", System.Data.SqlDbType.NVarChar, 20);
            paramNvNorme.Value = norme;
            maRequete.Parameters.Add(paramNvNorme);

            SqlParameter paramDateNorme = new SqlParameter("@dateNorme", System.Data.SqlDbType.Date);
            paramDateNorme.Value = date;
            maRequete.Parameters.Add(paramDateNorme);

            SqlParameter paramIdNorme = new SqlParameter("@idNorme", System.Data.SqlDbType.Int);
            paramIdNorme.Value = num;
            maRequete.Parameters.Add(paramIdNorme);

            maRequete.ExecuteReader();
           
        }


        public static void insertWorkflows(string code,int ept,int dcs,DateTime date)
        {
            

            SqlCommand maRequete = new SqlCommand("prc_ajoutWorkFlow",Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter depotlegal = new SqlParameter("@code", System.Data.SqlDbType.NVarChar,10);
            depotlegal.Value = code;
            maRequete.Parameters.Add(depotlegal);

            SqlParameter Etape = new SqlParameter("@ept", System.Data.SqlDbType.Int);
            Etape.Value = ept;
            maRequete.Parameters.Add(Etape);


            SqlParameter decision = new SqlParameter("@dsc", System.Data.SqlDbType.Int);
            decision.Value = dcs;
            maRequete.Parameters.Add(decision);

            SqlParameter DATE = new SqlParameter("@date", System.Data.SqlDbType.Date);
            DATE.Value = date;
            maRequete.Parameters.Add(DATE);

          
            maRequete.ExecuteNonQuery();

        }

        public static void updateAMM(string AMM, string depotlegal)
        {

            SqlCommand maRequete = new SqlCommand("prc_updateAMM", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter codeAMM = new SqlParameter("@AMM", System.Data.SqlDbType.NVarChar, 10);
            codeAMM.Value = AMM;
            maRequete.Parameters.Add(codeAMM);

            SqlParameter depot = new SqlParameter("@depotlegal", System.Data.SqlDbType.NVarChar, 10);
            depot.Value = depotlegal;
            maRequete.Parameters.Add(depot);

            maRequete.ExecuteNonQuery();
        }

        public static void ajouterMedicament(string depotLegal, string nomCommercial, string medComposition, string medEffet, string medContreIndic, string codeFamilleMed)
        {
            SqlCommand maRequete = new SqlCommand("prc_ajouter_medicament", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter depot = new SqlParameter("@depotL", System.Data.SqlDbType.NVarChar, 10);
            depot.Value = depotLegal;
            maRequete.Parameters.Add(depot);

            SqlParameter nomC = new SqlParameter("@nomCom", System.Data.SqlDbType.NVarChar, 25);
            nomC.Value = nomCommercial;
            maRequete.Parameters.Add(nomC);

            SqlParameter Compo = new SqlParameter("@medComp", System.Data.SqlDbType.NVarChar, 255);
            Compo.Value = medComposition;
            maRequete.Parameters.Add(Compo);

            SqlParameter Eff = new SqlParameter("@medEff", System.Data.SqlDbType.NVarChar, 255);
            Eff.Value = medEffet;
            maRequete.Parameters.Add(Eff);

            SqlParameter ContreIndic = new SqlParameter("@medConInd", System.Data.SqlDbType.NVarChar, 255);
            ContreIndic.Value = medContreIndic;
            maRequete.Parameters.Add(ContreIndic);

            SqlParameter Famille = new SqlParameter("@codeMed", System.Data.SqlDbType.NVarChar, 3);
            Famille.Value = codeFamilleMed;
            maRequete.Parameters.Add(Famille);

            maRequete.ExecuteNonQuery();
        }

    }
}
