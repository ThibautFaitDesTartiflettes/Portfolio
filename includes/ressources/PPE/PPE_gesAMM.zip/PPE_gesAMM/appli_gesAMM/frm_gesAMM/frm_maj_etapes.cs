﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class frm_maj_etapes : Form
    {
        public frm_maj_etapes()
        {
            InitializeComponent();
        }

        public void enableBouton()
        {
            if (cbNumero.Text != "")
            {
                if (tbNorme.Text != "")
                {
                    btModifier.Enabled = true;
                }
                else
                {
                    btModifier.Enabled = false;
                }
            }
            else
            {
                btModifier.Enabled = false;
            }
        }

        public void chargerListe()
        {
            lvEtape.Items.Clear();

            foreach (Etape uneEtape in Globale.lesEtapes)
            {
                ListViewItem ligne = new ListViewItem();

                ligne.Text = uneEtape.getNum().ToString();
                ligne.SubItems.Add(uneEtape.getLibelle());

                if (uneEtape.GetType().Name == "EtapeNormee")
                {
                    ligne.SubItems.Add((uneEtape as EtapeNormee).getNorme());
                    ligne.SubItems.Add((uneEtape as EtapeNormee).getDateNorme().ToShortDateString());
                }
                else
                {
                    ligne.SubItems.Add("");
                    ligne.SubItems.Add("");
                }

                lvEtape.Items.Add(ligne);
                lvEtape.Sorting = SortOrder.Ascending;
            }
        }

        private void frm_maj_etapes_Load(object sender, EventArgs e)
        {
            chargerListe();
            foreach (Etape uneEtape in Globale.lesEtapes)
            {
                if (uneEtape.GetType().Name == "EtapeNormee")
                {
                    cbNumero.Items.Add(uneEtape.getNum().ToString() + " - " + uneEtape.getLibelle());
                }
            }
        }

        private void tbNorme_TextChanged(object sender, EventArgs e)
        {
            enableBouton();
        }

        private void mcDateNorme_DateChanged(object sender, DateRangeEventArgs e)
        {
            enableBouton();
        }

        private void btModifier_Click(object sender, EventArgs e)
        {
            if (cbNumero.Text != "" && tbNorme.Text != "" && mcDateNorme.SelectionStart != DateTime.Today)
            {

                int numero = int.Parse(cbNumero.Text.Substring(0, 1)) - 1;
                string libelle = Globale.lesEtapes.ElementAt(numero).getLibelle();

                //Globale.lesEtapes.Remove(Globale.lesEtapes.ElementAt(numero));
                EtapeNormee uneEtapeNormee = new EtapeNormee(numero + 1, libelle, tbNorme.Text, mcDateNorme.SelectionStart);
                //Globale.lesEtapes.Add(uneEtapeNormee);
                
                bd.updateNormeEtape(int.Parse(cbNumero.Text.Substring(0, 1)), tbNorme.Text, mcDateNorme.SelectionStart);
                tbNorme.Clear();
                cbNumero.Items.Clear();
                chargerListe();

            }
        }

        private void gbModif_Enter(object sender, EventArgs e)
        {

        }
    }
}
