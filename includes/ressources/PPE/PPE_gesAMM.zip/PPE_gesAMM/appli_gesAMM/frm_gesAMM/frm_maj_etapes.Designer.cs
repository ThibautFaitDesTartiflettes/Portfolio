﻿namespace frm_gesAMM
{
    partial class frm_maj_etapes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvEtape = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbNorme = new System.Windows.Forms.TextBox();
            this.gbModif = new System.Windows.Forms.GroupBox();
            this.cbNumero = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btModifier = new System.Windows.Forms.Button();
            this.mcDateNorme = new System.Windows.Forms.MonthCalendar();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gbModif.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvEtape
            // 
            this.lvEtape.BackColor = System.Drawing.SystemColors.Window;
            this.lvEtape.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.lvEtape.HideSelection = false;
            this.lvEtape.Location = new System.Drawing.Point(12, 48);
            this.lvEtape.Name = "lvEtape";
            this.lvEtape.Size = new System.Drawing.Size(700, 426);
            this.lvEtape.TabIndex = 0;
            this.lvEtape.UseCompatibleStateImageBehavior = false;
            this.lvEtape.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Numéro";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Libellé";
            this.columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Norme";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Date de la norme";
            this.columnHeader4.Width = 140;
            // 
            // tbNorme
            // 
            this.tbNorme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.tbNorme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbNorme.Location = new System.Drawing.Point(137, 74);
            this.tbNorme.MaxLength = 20;
            this.tbNorme.Name = "tbNorme";
            this.tbNorme.Size = new System.Drawing.Size(262, 27);
            this.tbNorme.TabIndex = 1;
            this.tbNorme.TextChanged += new System.EventHandler(this.tbNorme_TextChanged);
            // 
            // gbModif
            // 
            this.gbModif.Controls.Add(this.cbNumero);
            this.gbModif.Controls.Add(this.label3);
            this.gbModif.Controls.Add(this.btModifier);
            this.gbModif.Controls.Add(this.mcDateNorme);
            this.gbModif.Controls.Add(this.label2);
            this.gbModif.Controls.Add(this.label1);
            this.gbModif.Controls.Add(this.tbNorme);
            this.gbModif.Location = new System.Drawing.Point(728, 48);
            this.gbModif.Name = "gbModif";
            this.gbModif.Size = new System.Drawing.Size(449, 426);
            this.gbModif.TabIndex = 2;
            this.gbModif.TabStop = false;
            this.gbModif.Text = "Modifier une étape normée";
            this.gbModif.Enter += new System.EventHandler(this.gbModif_Enter);
            // 
            // cbNumero
            // 
            this.cbNumero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.cbNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbNumero.FormattingEnabled = true;
            this.cbNumero.Location = new System.Drawing.Point(137, 34);
            this.cbNumero.Name = "cbNumero";
            this.cbNumero.Size = new System.Drawing.Size(262, 28);
            this.cbNumero.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Numéro :";
            // 
            // btModifier
            // 
            this.btModifier.Enabled = false;
            this.btModifier.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btModifier.Location = new System.Drawing.Point(186, 342);
            this.btModifier.Name = "btModifier";
            this.btModifier.Size = new System.Drawing.Size(177, 51);
            this.btModifier.TabIndex = 7;
            this.btModifier.Text = "MODIFIER";
            this.btModifier.UseVisualStyleBackColor = true;
            this.btModifier.Click += new System.EventHandler(this.btModifier_Click);
            // 
            // mcDateNorme
            // 
            this.mcDateNorme.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.mcDateNorme.Location = new System.Drawing.Point(137, 113);
            this.mcDateNorme.Name = "mcDateNorme";
            this.mcDateNorme.TabIndex = 6;
            this.mcDateNorme.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mcDateNorme_DateChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Date :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Norme :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(166, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(321, 26);
            this.label4.TabIndex = 4;
            this.label4.Text = "Mise à jour des étapes normées";
            // 
            // frm_maj_etapes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1189, 484);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gbModif);
            this.Controls.Add(this.lvEtape);
            this.Name = "frm_maj_etapes";
            this.Text = "Mise à jour des étapes normées";
            this.Load += new System.EventHandler(this.frm_maj_etapes_Load);
            this.gbModif.ResumeLayout(false);
            this.gbModif.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvEtape;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.TextBox tbNorme;
        private System.Windows.Forms.GroupBox gbModif;
        private System.Windows.Forms.Button btModifier;
        private System.Windows.Forms.MonthCalendar mcDateNorme;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbNumero;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}