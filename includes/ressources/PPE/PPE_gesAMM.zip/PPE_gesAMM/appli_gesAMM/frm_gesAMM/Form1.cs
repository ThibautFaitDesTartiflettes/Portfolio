﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_gesAMM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void débloquerMenu()
        {
            menuStrip1.Enabled = true;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // mettre dans le premier paramètre le nom de son pc, dans le deuxième le nom de la base
            Globale.LoadConnexion("localhost\\SQLEXPRESS", "dtb_gesAMM");

            Globale.lesMedicaments = new Dictionary<string, Medicament>();
            Globale.lesEtapes = new List<Etape>();
            Globale.lesFamilles = new Dictionary<string, Famille>();
            Globale.lesDecisions = new List<Decision>();
        

            bd.lireLesFamilles();
            bd.lireLesMedicaments();
            bd.lireLesEtapes();
            bd.lireLesDecisions();

            frm_connexion maForm = new frm_connexion(this);
            maForm.MdiParent = this;
            maForm.Show();
        }


        private void ajouterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAjouterMedicament medoc = new FrmAjouterMedicament();
            medoc.MdiParent = this;
            medoc.Show();
        }


        private void workflowDesÉtapesDunMédicamentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frm_consult_workflow frmConsultWorkflow = new frm_consult_workflow();
            frmConsultWorkflow.MdiParent = this;
            frmConsultWorkflow.Show();
        }

        private void nombreDeMédicamentAutoriséParFamilleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_medicament_autorise frm = new frm_medicament_autorise();

            frm.MdiParent = this;
            frm.Show();
        }

        private void médicamentEnCoursDeValidationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultationMedicament frm = new frmConsultationMedicament();
            frm.MdiParent = this;
            frm.Show();
        }

        private void saisirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSaisie frm = new frmSaisie();
            frm.MdiParent = this;
            frm.Show();
        }

        private void modifierUneÉtapeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frm_maj_etapes frm = new frm_maj_etapes();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
