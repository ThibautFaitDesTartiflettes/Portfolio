﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class Decision
    {
        private int id;
        private string libelle;

        public Decision(int leId, string leLibelle)
        {
            this.id = leId;
            this.libelle = leLibelle;
        }

        public int getId() { return this.id; }
        public string getLibelle() { return this.libelle; }

        public void setId(int leId) { this.id = leId; }
        public void setLibelle(string leLibelle) { this.libelle = leLibelle; }
    }
}
