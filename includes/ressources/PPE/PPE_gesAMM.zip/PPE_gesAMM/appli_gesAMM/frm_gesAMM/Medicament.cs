﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frm_gesAMM
{
    class Medicament
    {
        private string depotLegal;
        private string nomCommercial;
        private string composition;
        private string effets;
        private string contreIndications;
        private string amm;
        private int derniereEtape;
        private string codeFamille;
        private List<Workflow> lesWorkflows;

        public Medicament(string leDepotLegal, string leNomCommercial, string laComposition, string leEffets, string laContreIndications, string leAmm, int laDerniereEtape, string leCodeFamille)
        {
            this.depotLegal = leDepotLegal;
            this.nomCommercial = leNomCommercial;
            this.composition = laComposition;
            this.effets = leEffets;
            this.contreIndications = laContreIndications;
            this.amm = leAmm;
            this.derniereEtape = laDerniereEtape;
            this.codeFamille = leCodeFamille;
            this.lesWorkflows = new List<Workflow>();
        }

        public string getDepotLegal() { return this.depotLegal; }
        public string getNomCommercial() { return this.nomCommercial; }
        public string getComposition() { return this.composition; }
        public string getEffets() { return this.effets; }
        public string getContreIndications() { return this.contreIndications; }
        public string getAmm() { return this.amm; }
        public int getDerniereEtape() { return this.derniereEtape; }
        public string getCodeFamille() { return this.codeFamille; }
        public List<Workflow> getLesWorkflows() { return this.lesWorkflows; }

        public bool EstEnCours()
        {
            if (this.lesWorkflows.Count > 0)
            {
                Console.WriteLine(this.depotLegal);
                if (this.lesWorkflows[(this.lesWorkflows.Count - 1)].getIdDecision() == 0 && this.derniereEtape < 8)
                {
                 
                    return true;
                }

            }
            else
            {
                return true;
            }


            return false;
        }


        public bool GetDernierWorkFlowValide()
        {
            if (lesWorkflows.Count > 0)
            {
                int i = lesWorkflows.Count - 1;

                if (lesWorkflows[i].getIdDecision() == 0)
                {
                    return true;
                }
                
            }

            return false;
        }

        public void setDepotLegal(string leDepotLegal) { this.depotLegal = leDepotLegal; }
        public void setNomCommercial(string leNomCommercial) { this.nomCommercial = leNomCommercial; }
        public void setComposition (string laComposition) { this.composition = laComposition; }
        public void setEffets(string leEffets) { this.effets = leEffets; }
        public void setContreIndications(string laContreIndications) { this.contreIndications = laContreIndications; }
        public void setAmm(string leAmm) { this.amm = leAmm; }
        public void setDerniereEtape(int laDerniereEtape) { this.derniereEtape = laDerniereEtape; }
        public void setCodeFamille(string leCodeFamille) { this.codeFamille = leCodeFamille; }
        public void setLesWorkflows(List<Workflow> leLesWorkflows) { this.lesWorkflows = leLesWorkflows; }
    }
}
