﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DP2_MDI
{
    class Globale
    {
        public static int nbMaxNiveaux = 5;     //Nombre maximum de niveaux
        public static int plafondScore = 10;    //Score maximum par niveau
        public static Joueur leJoueurTest;      //Joueur du test
    }
}
